# قوانین Proguard/R8 در صورت فعال‌سازی minify اضافه شود.

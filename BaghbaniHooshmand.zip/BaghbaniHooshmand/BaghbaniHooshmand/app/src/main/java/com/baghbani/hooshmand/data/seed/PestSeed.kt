package com.baghbani.hooshmand.data.seed

import com.baghbani.hooshmand.data.local.entity.PestEntity
import com.baghbani.hooshmand.data.local.entity.TreeCategory

object PestSeed {

    fun list(): List<PestEntity> = listOf(
        PestEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "کرم سیب",
            shortDescription = "لارو داخل میوه نفوذ کرده و کانال‌های زرد ایجاد می‌کند.",
            imageRes = "pest_codling_moth",
            solutionSteps = listOf(
                "از تله فرومونی برای پایش پرواز حشره کامل استفاده کنید",
                "میوه‌های آلوده ریخته‌شده را جمع‌آوری و معدوم کنید",
                "در زمان اوج پرواز حشره‌کش مناسب طبق دستور بزنید",
                "نوار مقوایی دور تنه ببندید تا لارو در آن به دام بیفتد"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "شپشک آرد آلود",
            shortDescription = "پوشش پنبه‌مانند سفید روی شاخه و برگ که شیره گیاه می‌مکد.",
            imageRes = "pest_mealybug",
            solutionSteps = listOf(
                "با فشار آب شپشک‌ها را از روی شاخه بشویید",
                "روغن باغی را در زمستان زودهنگام محلول‌پاشی کنید",
                "شاخه‌های به‌شدت آلوده را هرس و معدوم کنید",
                "از دشمنان طبیعی مانند کفشدوزک استفاده کنید"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "کنه قرمز اروپایی",
            shortDescription = "نقاط ریز قرمز روی برگ که باعث رنگ‌پریدگی و ریزش برگ می‌شود.",
            imageRes = "pest_mite",
            solutionSteps = listOf(
                "روغن ولک زمستانه قبل از باز شدن جوانه بزنید",
                "در تابستان از کنه‌کش اختصاصی طبق دستور استفاده کنید",
                "از سم‌پاشی بیش‌ازحد که دشمنان طبیعی را از بین می‌برد پرهیز کنید"
            ), priority = 3
        ),
        PestEntity(
            category = TreeCategory.VINE, nameFa = "شته انگور",
            shortDescription = "حشرات ریز سبز یا سیاه که شیره برگ و جوانه را می‌مکند.",
            imageRes = "pest_aphid",
            solutionSteps = listOf(
                "با فشار آب حشرات را از روی برگ بشویید",
                "از صابون حشره‌کش یا روغن نیم استفاده کنید",
                "علف‌های هرز اطراف بوته را کنترل کنید",
                "در صورت شدت آلودگی حشره‌کش سیستمیک طبق برچسب استفاده کنید"
            ), priority = 3
        ),
        PestEntity(
            category = TreeCategory.POMEGRANATE, nameFa = "کرم گلوگاه انار",
            shortDescription = "مهم‌ترین آفت انار؛ لارو داخل میوه نفوذ کرده و باعث پوسیدگی و ترک‌خوردگی می‌شود.",
            imageRes = "pest_pomegranate_moth",
            solutionSteps = listOf(
                "میوه‌های ترک‌خورده و آلوده را فوراً جمع‌آوری و معدوم کنید",
                "از تله فرومونی برای پایش استفاده کنید",
                "در زمان تخم‌ریزی حشره‌کش مناسب طبق دستور کارشناس بزنید",
                "هرس برای بهبود تهویه و کاهش رطوبت انجام دهید"
            ), priority = 1
        ),
        PestEntity(
            category = TreeCategory.NUT, nameFa = "پسیل معمولی پسته",
            shortDescription = "حشره‌ای که شیره برگ پسته را مکیده و باعث لکه و ریزش برگ می‌شود.",
            imageRes = "pest_psylla",
            solutionSteps = listOf(
                "با تله چسبان زرد جمعیت آفت را پایش کنید",
                "در اوج فعالیت حشره‌کش طبق دستور کارشناس بزنید",
                "از دشمنان طبیعی مانند زنبورهای پارازیتوئید حمایت کنید"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.NUT, nameFa = "مگس گردو (کرم گردو)",
            shortDescription = "لارو داخل پوست سبز گردو نفوذ کرده و باعث سیاه‌شدگی می‌شود.",
            imageRes = "pest_walnut_fly",
            solutionSteps = listOf(
                "پوست‌های آلوده ریخته‌شده را جمع‌آوری و معدوم کنید",
                "از تله چسبان زرد برای پایش استفاده کنید",
                "در اوج پرواز حشره کامل حشره‌کش طبق دستور بزنید"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.CITRUS, nameFa = "شپشک استرالیایی مرکبات",
            shortDescription = "پوسته‌های قهوه‌ای گرد روی شاخه و برگ که شیره گیاه می‌مکد.",
            imageRes = "pest_citrus_scale",
            solutionSteps = listOf(
                "روغن باغی را در بهار و پاییز محلول‌پاشی کنید",
                "شاخه‌های به‌شدت آلوده را هرس کنید",
                "از کفشدوزک استرالیایی به‌عنوان دشمن طبیعی استفاده کنید"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.OLIVE, nameFa = "مگس میوه زیتون",
            shortDescription = "لارو داخل میوه زیتون نفوذ کرده و کیفیت روغن را کاهش می‌دهد.",
            imageRes = "pest_olive_fly",
            solutionSteps = listOf(
                "از تله‌های فرومونی برای پایش و شکار انبوه استفاده کنید",
                "میوه‌های ریخته‌شده را جمع‌آوری و معدوم کنید",
                "در اوج فعالیت حشره‌کش طعمه‌ای طبق دستور کارشناس بزنید"
            ), priority = 2
        ),
        PestEntity(
            category = TreeCategory.SPECIAL, nameFa = "کنه‌های انجیر و توت",
            shortDescription = "کنه‌های ریز که در زیر برگ تغذیه کرده و باعث لکه و ریزش برگ می‌شوند.",
            imageRes = "pest_fig_mite",
            solutionSteps = listOf(
                "برگ‌های به‌شدت آلوده را حذف و معدوم کنید",
                "روغن نیم یا صابون حشره‌کش محلول‌پاشی کنید",
                "رطوبت محیط را با آبپاشی سبک برگ افزایش دهید (کنه‌ها هوای خشک را دوست دارند)"
            ), priority = 3
        ),
        PestEntity(
            category = TreeCategory.PALM, nameFa = "سوسک سرخرطومی حنایی خرما",
            shortDescription = "آفت خطرناک که لارو آن داخل تنه نخل تغذیه کرده و باعث مرگ درخت می‌شود.",
            imageRes = "pest_weevil",
            solutionSteps = listOf(
                "تنه نخل را به‌طور مرتب از نظر سوراخ و ترشح بررسی کنید",
                "از تله فرومونی برای پایش استفاده کنید",
                "در صورت مشاهده علائم، فوراً با کارشناس گیاه‌پزشکی تماس بگیرید",
                "زخم‌های حاصل از هرس را با ترکیبات محافظ بپوشانید"
            ), priority = 1
        )
    )
}

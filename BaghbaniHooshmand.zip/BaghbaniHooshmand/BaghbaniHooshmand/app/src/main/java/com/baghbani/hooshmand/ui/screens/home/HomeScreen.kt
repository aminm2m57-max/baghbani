package com.baghbani.hooshmand.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.ui.components.StatCard
import com.baghbani.hooshmand.ui.components.TreeSummaryCard
import com.baghbani.hooshmand.ui.theme.StatusDanger
import com.baghbani.hooshmand.ui.theme.StatusHealthy
import com.baghbani.hooshmand.ui.theme.StatusWarning
import com.baghbani.hooshmand.util.PersianNumbers

@Composable
fun HomeScreen(
    repository: GardenRepository,
    onTreeClick: (Long) -> Unit,
    onAddTreeClick: () -> Unit,
    onSeeAllClick: () -> Unit
) {
    val viewModel: HomeViewModel = viewModel(
        factory = viewModelFactory { initializer { HomeViewModel(repository) } }
    )
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("باغ من", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "تعداد درخت", value = PersianNumbers.toPersian(state.totalCount),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "درصد سالم", value = "${PersianNumbers.toPersian(state.healthyPercent)}٪",
                    modifier = Modifier.weight(1f), color = StatusHealthy
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "بیماری", value = PersianNumbers.toPersian(state.diseaseCount),
                    modifier = Modifier.weight(1f), color = StatusDanger
                )
                StatCard(
                    title = "آفت", value = PersianNumbers.toPersian(state.pestCount),
                    modifier = Modifier.weight(1f), color = StatusWarning
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onAddTreeClick, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("افزودن درخت جدید")
                }
                OutlinedButton(onClick = onSeeAllClick, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.List, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("لیست تمام گیاهان")
                }
            }
        }

        item {
            Text("درخت‌های باغ شما", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        items(state.treesWithSpecies) { item ->
            TreeSummaryCard(item = item, onClick = { onTreeClick(item.tree.id) })
        }

        if (state.treesWithSpecies.isEmpty() && !state.isLoading) {
            item {
                Text(
                    "هنوز درختی اضافه نکرده‌اید. با دکمه «افزودن درخت جدید» شروع کنید.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

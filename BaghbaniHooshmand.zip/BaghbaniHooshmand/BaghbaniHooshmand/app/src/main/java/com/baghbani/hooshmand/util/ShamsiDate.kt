package com.baghbani.hooshmand.util

import java.util.Calendar

/**
 * تبدیل ساده تاریخ میلادی به شمسی برای نمایش در UI (بدون کتابخانه خارجی).
 * الگوریتم استاندارد تبدیل گرگوری به جلالی.
 */
object ShamsiDate {

    private val persianMonths = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun fromTimestamp(timestampMillis: Long): Triple<Int, Int, Int> {
        val cal = Calendar.getInstance().apply { timeInMillis = timestampMillis }
        return gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun formatTimestamp(timestampMillis: Long, usePersianDigits: Boolean = true): String {
        val (y, m, d) = fromTimestamp(timestampMillis)
        val monthName = persianMonths[m - 1]
        val dayStr = if (usePersianDigits) PersianNumbers.toPersian(d) else d.toString()
        val yearStr = if (usePersianDigits) PersianNumbers.toPersian(y) else y.toString()
        return "$dayStr $monthName $yearStr"
    }

    private fun gregorianToJalali(gYear: Int, gMonth: Int, gDay: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gy = gYear - 1600
        val gm = gMonth - 1
        val gd = gDay - 1

        var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
        for (i in 0 until gm) gDayNo += gDaysInMonth[i]
        if (gm > 1 && ((gYear % 4 == 0 && gYear % 100 != 0) || gYear % 400 == 0)) gDayNo += 1
        gDayNo += gd

        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053
        jDayNo %= 12053
        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461
        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }

        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
        var i = 0
        var jm = 1
        while (i < 11 && jDayNo >= jDaysInMonth[i]) {
            jDayNo -= jDaysInMonth[i]
            i++
            jm++
        }
        val jd = jDayNo + 1

        return Triple(jy, jm, jd)
    }
}

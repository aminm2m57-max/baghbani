package com.baghbani.hooshmand.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = GreenSurfaceLight,
    secondary = EarthBrown,
    tertiary = SunYellow,
    background = androidx.compose.ui.graphics.Color(0xFFFDFDF6),
    surface = androidx.compose.ui.graphics.Color.White,
    error = StatusDanger
)

private val DarkColors = darkColorScheme(
    primary = GreenLight,
    onPrimary = androidx.compose.ui.graphics.Color.Black,
    primaryContainer = GreenPrimaryDark,
    secondary = EarthBrown,
    tertiary = SunYellow,
    background = DarkBackground,
    surface = DarkSurface,
    error = StatusDanger
)

/**
 * تم اصلی اپلیکیشن — همیشه با جهت راست‌به‌چپ (RTL) برای پشتیبانی کامل فارسی.
 */
@Composable
fun BaghbaniHooshmandTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colors,
            typography = AppTypography,
            content = content
        )
    }
}

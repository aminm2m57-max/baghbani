package com.baghbani.hooshmand.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.baghbani.hooshmand.data.local.entity.DiseaseEntity
import com.baghbani.hooshmand.data.local.entity.GraftMethodEntity
import com.baghbani.hooshmand.data.local.entity.PestEntity
import com.baghbani.hooshmand.data.local.entity.TreeCategory
import kotlinx.coroutines.flow.Flow

@Dao
interface DiseaseDao {
    @Query("SELECT * FROM diseases WHERE category = :category")
    fun getDiseasesForCategory(category: TreeCategory): Flow<List<DiseaseEntity>>

    @Query("SELECT * FROM diseases ORDER BY priority ASC")
    fun getAllDiseasesSortedByPriority(): Flow<List<DiseaseEntity>>

    @Query("SELECT COUNT(*) FROM diseases")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<DiseaseEntity>)
}

@Dao
interface PestDao {
    @Query("SELECT * FROM pests WHERE category = :category")
    fun getPestsForCategory(category: TreeCategory): Flow<List<PestEntity>>

    @Query("SELECT * FROM pests ORDER BY priority ASC")
    fun getAllPestsSortedByPriority(): Flow<List<PestEntity>>

    @Query("SELECT COUNT(*) FROM pests")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<PestEntity>)
}

@Dao
interface GraftMethodDao {
    @Query("SELECT * FROM graft_methods WHERE category = :category")
    fun getGraftMethodsForCategory(category: TreeCategory): Flow<List<GraftMethodEntity>>

    @Query("SELECT COUNT(*) FROM graft_methods")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<GraftMethodEntity>)
}

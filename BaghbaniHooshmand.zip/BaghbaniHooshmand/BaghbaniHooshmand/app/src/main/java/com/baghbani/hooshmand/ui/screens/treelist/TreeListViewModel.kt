package com.baghbani.hooshmand.ui.screens.treelist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.ui.screens.home.TreeWithSpecies
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class TreeListViewModel(private val repository: GardenRepository) : ViewModel() {

    val trees: StateFlow<List<TreeWithSpecies>> = combine(
        repository.getAllTrees(),
        repository.getAllSpecies()
    ) { treeList, speciesList ->
        val speciesMap = speciesList.associateBy { it.id }
        treeList.mapNotNull { t -> speciesMap[t.speciesId]?.let { TreeWithSpecies(t, it) } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

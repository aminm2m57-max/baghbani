package com.baghbani.hooshmand.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

/**
 * فونت پیش‌فرض سیستم برای متن فارسی (Sans Serif از پلتفرم پشتیبانی کامل RTL دارد).
 *
 * برای استفاده از فونت اختصاصی Vazirmatn (پیشنهادی برای ظاهر حرفه‌ای‌تر):
 * ۱. فایل‌های vazirmatn_regular.ttf ، vazirmatn_medium.ttf ، vazirmatn_bold.ttf را
 *    از https://github.com/rastikerdar/vazirmatn دانلود کنید.
 * ۲. آن‌ها را در res/font/ قرار دهید.
 * ۳. FontFamily زیر را جایگزین کنید با:
 *    FontFamily(
 *        Font(R.font.vazirmatn_regular, FontWeight.Normal),
 *        Font(R.font.vazirmatn_medium, FontWeight.Medium),
 *        Font(R.font.vazirmatn_bold, FontWeight.Bold)
 *    )
 */
val VazirFontFamily = FontFamily.SansSerif

val AppTypography = Typography(
    headlineLarge = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp),
    headlineMedium = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleLarge = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Medium, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Medium, fontSize = 17.sp),
    bodyLarge = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontFamily = VazirFontFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp)
)


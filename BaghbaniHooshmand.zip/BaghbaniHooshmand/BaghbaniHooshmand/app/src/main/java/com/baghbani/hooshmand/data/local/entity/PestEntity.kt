package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pests")
data class PestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val category: TreeCategory,
    val nameFa: String,
    val shortDescription: String,
    val imageRes: String,
    val solutionSteps: List<String>,
    val priority: Int = 2
)

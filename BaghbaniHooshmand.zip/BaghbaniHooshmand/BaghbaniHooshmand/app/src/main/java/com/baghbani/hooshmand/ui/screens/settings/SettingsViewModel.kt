package com.baghbani.hooshmand.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.datastore.SettingsDataStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settingsDataStore: SettingsDataStore) : ViewModel() {

    val darkTheme: StateFlow<Boolean> = settingsDataStore.isDarkTheme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val persianNumbers: StateFlow<Boolean> = settingsDataStore.usePersianNumbers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val autoSave: StateFlow<Boolean> = settingsDataStore.isAutoSaveEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun setDarkTheme(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setDarkTheme(enabled) }
    fun setPersianNumbers(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setPersianNumbers(enabled) }
    fun setAutoSave(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setAutoSave(enabled) }
}

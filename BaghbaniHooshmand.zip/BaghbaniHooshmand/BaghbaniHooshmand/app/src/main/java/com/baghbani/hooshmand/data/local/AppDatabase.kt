package com.baghbani.hooshmand.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.baghbani.hooshmand.data.local.converter.Converters
import com.baghbani.hooshmand.data.local.dao.ActivityDao
import com.baghbani.hooshmand.data.local.dao.DiseaseDao
import com.baghbani.hooshmand.data.local.dao.GraftMethodDao
import com.baghbani.hooshmand.data.local.dao.GrowthRecordDao
import com.baghbani.hooshmand.data.local.dao.PestDao
import com.baghbani.hooshmand.data.local.dao.TreeDao
import com.baghbani.hooshmand.data.local.dao.TreeSpeciesDao
import com.baghbani.hooshmand.data.local.entity.ActivityEntity
import com.baghbani.hooshmand.data.local.entity.DiseaseEntity
import com.baghbani.hooshmand.data.local.entity.GraftMethodEntity
import com.baghbani.hooshmand.data.local.entity.GrowthRecordEntity
import com.baghbani.hooshmand.data.local.entity.PestEntity
import com.baghbani.hooshmand.data.local.entity.TreeEntity
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity

@Database(
    entities = [
        TreeSpeciesEntity::class,
        TreeEntity::class,
        DiseaseEntity::class,
        PestEntity::class,
        GraftMethodEntity::class,
        ActivityEntity::class,
        GrowthRecordEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun treeSpeciesDao(): TreeSpeciesDao
    abstract fun treeDao(): TreeDao
    abstract fun diseaseDao(): DiseaseDao
    abstract fun pestDao(): PestDao
    abstract fun graftMethodDao(): GraftMethodDao
    abstract fun activityDao(): ActivityDao
    abstract fun growthRecordDao(): GrowthRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "baghbani_hooshmand.db"
                ).build().also { INSTANCE = it }
            }
    }
}

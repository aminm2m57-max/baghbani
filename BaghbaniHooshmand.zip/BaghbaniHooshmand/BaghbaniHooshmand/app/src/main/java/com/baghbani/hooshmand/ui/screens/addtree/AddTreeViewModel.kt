package com.baghbani.hooshmand.ui.screens.addtree

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.local.entity.HealthStatus
import com.baghbani.hooshmand.data.local.entity.TreeEntity
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity
import com.baghbani.hooshmand.data.repository.GardenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AddTreeViewModel(private val repository: GardenRepository) : ViewModel() {

    val allSpecies: StateFlow<List<TreeSpeciesEntity>> =
        repository.getAllSpecies().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTree(
        speciesId: Long,
        nickname: String?,
        plantedYear: Int?,
        ageYears: Int,
        imageUri: String?,
        onDone: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.addTree(
                TreeEntity(
                    speciesId = speciesId,
                    nickname = nickname,
                    plantedYear = plantedYear,
                    ageYears = ageYears,
                    imageUri = imageUri,
                    healthStatus = HealthStatus.HEALTHY
                )
            )
            onDone(id)
        }
    }
}

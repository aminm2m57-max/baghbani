package com.baghbani.hooshmand.ui.theme

import androidx.compose.ui.graphics.Color

// پالت اصلی - سبز طبیعی و باغبانی
val GreenPrimary = Color(0xFF2E7D32)
val GreenPrimaryDark = Color(0xFF1B5E20)
val GreenLight = Color(0xFF81C784)
val GreenSurfaceLight = Color(0xFFF1F8E9)

val EarthBrown = Color(0xFF6D4C41)
val SunYellow = Color(0xFFFBC02D)

val StatusHealthy = Color(0xFF43A047)
val StatusWarning = Color(0xFFFB8C00)
val StatusDanger = Color(0xFFE53935)

val DarkBackground = Color(0xFF121B12)
val DarkSurface = Color(0xFF1D291D)

package com.baghbani.hooshmand.ui.screens.general

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.repository.GardenRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneralInfoScreen(
    repository: GardenRepository,
    onBack: () -> Unit
) {
    val viewModel: GeneralInfoViewModel = viewModel(
        factory = viewModelFactory { initializer { GeneralInfoViewModel(repository) } }
    )
    val species by viewModel.allSpecies.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("خلاصه هر گونه", "جدول مقایسه‌ای")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("اطلاعات کلی باغبانی") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = selectedTab == index, onClick = { selectedTab = index }, text = { Text(title) })
                }
            }

            if (selectedTab == 0) {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(species) { s ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(s.nameFa, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(s.scientificName, style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("دسته: ${s.category.displayNameFa}", style = MaterialTheme.typography.bodyMedium)
                                Text("عمر: ${s.avgLifespanYears}", style = MaterialTheme.typography.bodyMedium)
                                Text("نیاز نوری: ${s.lightNeed}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).padding(16.dp)) {
                    ComparisonTable(species = species)
                }
            }
        }
    }
}

@Composable
private fun ComparisonTable(species: List<com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity>) {
    Column {
        Row {
            TableCell("نام", header = true, width = 110)
            TableCell("دسته", header = true, width = 110)
            TableCell("آبیاری", header = true, width = 160)
            TableCell("کوددهی", header = true, width = 160)
            TableCell("سم‌پاشی", header = true, width = 160)
        }
        Divider()
        species.forEach { s ->
            Row {
                TableCell(s.nameFa, width = 110)
                TableCell(s.category.displayNameFa, width = 110)
                TableCell(s.wateringFrequency, width = 160)
                TableCell(s.fertilizerSchedule, width = 160)
                TableCell(s.pesticideSchedule, width = 160)
            }
            Divider()
        }
    }
}

@Composable
private fun TableCell(text: String, header: Boolean = false, width: Int) {
    Box(modifier = Modifier.width(width.dp).padding(8.dp)) {
        Text(
            text,
            style = if (header) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyMedium,
            fontWeight = if (header) FontWeight.Bold else FontWeight.Normal
        )
    }
}

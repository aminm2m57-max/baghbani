package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

enum class HealthStatus(val displayNameFa: String) {
    HEALTHY("سالم"),
    MINOR_ISSUE("مشکل جزئی"),
    DISEASED("بیمار"),
    PEST_AFFECTED("آفت‌زده"),
    CRITICAL("بحرانی")
}

/**
 * درخت واقعی موجود در باغ کاربر — به یک گونه مرجع (TreeSpeciesEntity) وصل است.
 */
@Entity(
    tableName = "trees",
    foreignKeys = [
        ForeignKey(
            entity = TreeSpeciesEntity::class,
            parentColumns = ["id"],
            childColumns = ["speciesId"]
        )
    ]
)
data class TreeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val speciesId: Long,
    val nickname: String? = null,       // نام دلخواه کاربر برای این درخت خاص (اختیاری)
    val plantedYear: Int? = null,       // سال کاشت
    val ageYears: Int,                  // عمر تقریبی فعلی
    val imageUri: String? = null,       // عکس اختصاصی این درخت (در صورت وجود)
    val healthStatus: HealthStatus = HealthStatus.HEALTHY,
    val hasDisease: Boolean = false,
    val hasPest: Boolean = false,
    val isGrafted: Boolean = false,
    val personalNotes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

package com.baghbani.hooshmand.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "baghbani_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val PERSIAN_NUMBERS = booleanPreferencesKey("persian_numbers")
        val AUTO_SAVE = booleanPreferencesKey("auto_save")
    }

    val isOnboardingDone: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.ONBOARDING_DONE] ?: false }

    val isDarkTheme: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.DARK_THEME] ?: false }

    val usePersianNumbers: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.PERSIAN_NUMBERS] ?: true }

    val isAutoSaveEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.AUTO_SAVE] ?: true }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setPersianNumbers(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PERSIAN_NUMBERS] = enabled }
    }

    suspend fun setAutoSave(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SAVE] = enabled }
    }
}

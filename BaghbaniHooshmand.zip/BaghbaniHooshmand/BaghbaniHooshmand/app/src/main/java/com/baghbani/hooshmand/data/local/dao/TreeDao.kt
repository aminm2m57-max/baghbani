package com.baghbani.hooshmand.data.local.dao

import androidx.room.*
import com.baghbani.hooshmand.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TreeDao {

    @Query("SELECT * FROM trees ORDER BY createdAt DESC")
    fun getAllTrees(): Flow<List<TreeEntity>>

    @Query("SELECT * FROM trees WHERE id = :id")
    fun getTreeById(id: Long): Flow<TreeEntity?>

    @Query("SELECT COUNT(*) FROM trees")
    fun getTreeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trees WHERE healthStatus = 'HEALTHY'")
    fun getHealthyCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trees WHERE hasDisease = 1")
    fun getDiseasedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trees WHERE hasPest = 1")
    fun getPestAffectedCount(): Flow<Int>

    @Insert
    suspend fun insert(tree: TreeEntity): Long

    @Update
    suspend fun update(tree: TreeEntity)

    @Delete
    suspend fun delete(tree: TreeEntity)

    @Query("UPDATE trees SET personalNotes = :notes WHERE id = :treeId")
    suspend fun updateNotes(treeId: Long, notes: String)
}

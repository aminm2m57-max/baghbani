package com.baghbani.hooshmand.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.baghbani.hooshmand.data.datastore.SettingsDataStore
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.ui.screens.addtree.AddTreeScreen
import com.baghbani.hooshmand.ui.screens.garden.GardenManagementScreen
import com.baghbani.hooshmand.ui.screens.general.GeneralInfoScreen
import com.baghbani.hooshmand.ui.screens.home.HomeScreen
import com.baghbani.hooshmand.ui.screens.onboarding.OnboardingScreen
import com.baghbani.hooshmand.ui.screens.settings.SettingsScreen
import com.baghbani.hooshmand.ui.screens.treedetail.TreeDetailScreen
import com.baghbani.hooshmand.ui.screens.treelist.TreeListScreen

@Composable
fun BaghbaniNavHost(
    repository: GardenRepository,
    settingsDataStore: SettingsDataStore
) {
    val navController = rememberNavController()
    val onboardingDone by settingsDataStore.isOnboardingDone.collectAsState(initial = null)

    // تا مشخص شدن وضعیت onboarding چیزی نمایش نده (از فلیکر جلوگیری می‌کند)
    val startDestination = when (onboardingDone) {
        true -> NavRoutes.HOME
        false -> NavRoutes.ONBOARDING
        null -> return
    }

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route
            if (currentRoute != NavRoutes.ONBOARDING) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == NavRoutes.HOME,
                        onClick = { navController.navigate(NavRoutes.HOME) { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Home, contentDescription = "خانه") },
                        label = { Text("خانه") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == NavRoutes.GARDEN_MANAGEMENT,
                        onClick = { navController.navigate(NavRoutes.GARDEN_MANAGEMENT) { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Park, contentDescription = "مدیریت باغ") },
                        label = { Text("مدیریت باغ") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == NavRoutes.GENERAL_INFO,
                        onClick = { navController.navigate(NavRoutes.GENERAL_INFO) { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Menu, contentDescription = "اطلاعات کلی") },
                        label = { Text("اطلاعات کلی") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == NavRoutes.SETTINGS,
                        onClick = { navController.navigate(NavRoutes.SETTINGS) { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Settings, contentDescription = "تنظیمات") },
                        label = { Text("تنظیمات") }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(NavRoutes.ONBOARDING) {
                OnboardingScreen(
                    repository = repository,
                    settingsDataStore = settingsDataStore,
                    onFinished = {
                        navController.navigate(NavRoutes.HOME) {
                            popUpTo(NavRoutes.ONBOARDING) { inclusive = true }
                        }
                    }
                )
            }
            composable(NavRoutes.HOME) {
                HomeScreen(
                    repository = repository,
                    onTreeClick = { id -> navController.navigate(NavRoutes.treeDetail(id)) },
                    onAddTreeClick = { navController.navigate(NavRoutes.ADD_TREE) },
                    onSeeAllClick = { navController.navigate(NavRoutes.TREE_LIST) }
                )
            }
            composable(NavRoutes.TREE_LIST) {
                TreeListScreen(
                    repository = repository,
                    onTreeClick = { id -> navController.navigate(NavRoutes.treeDetail(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = NavRoutes.TREE_DETAIL,
                arguments = listOf(androidx.navigation.navArgument("treeId") { type = androidx.navigation.NavType.LongType })
            ) { backStackEntry ->
                val treeId = backStackEntry.arguments?.getLong("treeId") ?: 0L
                TreeDetailScreen(
                    repository = repository,
                    treeId = treeId,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(NavRoutes.ADD_TREE) {
                AddTreeScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onTreeAdded = { id ->
                        navController.navigate(NavRoutes.treeDetail(id)) {
                            popUpTo(NavRoutes.HOME)
                        }
                    }
                )
            }
            composable(NavRoutes.GARDEN_MANAGEMENT) {
                GardenManagementScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable(NavRoutes.GENERAL_INFO) {
                GeneralInfoScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable(NavRoutes.SETTINGS) {
                SettingsScreen(settingsDataStore = settingsDataStore, onBack = { navController.popBackStack() })
            }
        }
    }
}

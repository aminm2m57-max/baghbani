package com.baghbani.hooshmand.data.seed

import com.baghbani.hooshmand.data.local.entity.DiseaseEntity
import com.baghbani.hooshmand.data.local.entity.TreeCategory

object DiseaseSeed {

    fun list(): List<DiseaseEntity> = listOf(
        // میوه دانه‌دار (سیب، گلابی، به)
        DiseaseEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "لکه سیاه (اسکب)",
            shortDescription = "لکه‌های سیاه و مخملی روی برگ و میوه که باعث ترک‌خوردگی می‌شود.",
            imageRes = "disease_scab",
            solutionSteps = listOf(
                "برگ‌های آلوده ریخته‌شده را جمع‌آوری و از باغ خارج کنید",
                "قبل از باز شدن جوانه‌ها قارچ‌کش مسی محلول‌پاشی کنید",
                "در فصل رشد هر ۱۰ تا ۱۴ روز قارچ‌کش تناوبی استفاده کنید",
                "هرس درخت برای بهبود تهویه هوا انجام دهید"
            ), priority = 2
        ),
        DiseaseEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "آتشک (شانکر باکتریایی)",
            shortDescription = "پژمردگی ناگهانی شاخه‌ها به شکل سوخته با ترشح صمغ.",
            imageRes = "disease_fireblight",
            solutionSteps = listOf(
                "شاخه‌های آلوده را ۳۰ سانتی‌متر پایین‌تر از محل آلودگی قطع کنید",
                "ابزار هرس را بعد از هر برش با الکل ضدعفونی کنید",
                "از کوددهی ازته بیش‌ازحد در فصل رشد خودداری کنید",
                "در صورت شیوع، از باکتری‌کش مسی طبق دستور کارشناس استفاده کنید"
            ), priority = 1
        ),

        // میوه هسته‌دار
        DiseaseEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "پیچیدگی برگ هلو",
            shortDescription = "تاول و پیچیدگی قرمزرنگ روی برگ‌های جوان در بهار.",
            imageRes = "disease_leafcurl",
            solutionSteps = listOf(
                "در پاییز و اوایل زمستان قارچ‌کش مسی محلول‌پاشی کنید",
                "برگ‌های آلوده را جمع‌آوری و معدوم کنید",
                "قبل از باز شدن جوانه در اسفند دوباره سم‌پاشی کنید",
                "از آبیاری روی برگ خودداری کنید"
            ), priority = 2
        ),
        DiseaseEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "شانکر شاخه (گموز)",
            shortDescription = "ترشح صمغ از تنه و شاخه‌ها همراه با خشکیدگی موضعی.",
            imageRes = "disease_gummosis",
            solutionSteps = listOf(
                "بافت آلوده را با چاقوی تمیز تراشیده و خارج کنید",
                "محل زخم را با خمیر قارچ‌کش مسی پوشش دهید",
                "از زخمی شدن تنه در حین هرس و کار باغی خودداری کنید",
                "زهکشی خاک را بهبود دهید تا رطوبت اضافی نماند"
            ), priority = 2
        ),

        // انگور
        DiseaseEntity(
            category = TreeCategory.VINE, nameFa = "سفیدک پودری",
            shortDescription = "پودر سفید روی برگ و خوشه انگور که رشد میوه را مختل می‌کند.",
            imageRes = "disease_powdery_mildew",
            solutionSteps = listOf(
                "از ابتدای بهار هر ۱۰ تا ۱۵ روز گوگرد پودری بپاشید",
                "شاخ‌وبرگ اضافی را هرس کنید تا تهویه بهتر شود",
                "از آبیاری بارانی روی برگ خودداری کنید",
                "در صورت شدت آلودگی از قارچ‌کش سیستمیک استفاده کنید"
            ), priority = 2
        ),
        DiseaseEntity(
            category = TreeCategory.VINE, nameFa = "سفیدک داخلی (پرونوسپورا)",
            shortDescription = "لکه‌های روغنی زرد روی برگ و پوشش کرکی سفید در زیر برگ.",
            imageRes = "disease_downy_mildew",
            solutionSteps = listOf(
                "قارچ‌کش مسی (بردو) قبل از بارندگی‌های بهاره استفاده کنید",
                "برگ‌های آلوده را حذف و معدوم کنید",
                "تراکم بوته را کاهش دهید تا رطوبت کمتر بماند",
                "پس از هر بارندگی طولانی سم‌پاشی را تکرار کنید"
            ), priority = 2
        ),

        // انار
        DiseaseEntity(
            category = TreeCategory.POMEGRANATE, nameFa = "لکه سرکوسپورایی برگ",
            shortDescription = "لکه‌های قهوه‌ای گرد روی برگ‌ها که باعث ریزش زودرس می‌شود.",
            imageRes = "disease_leafspot",
            solutionSteps = listOf(
                "برگ‌های ریخته‌شده آلوده را جمع‌آوری و معدوم کنید",
                "قارچ‌کش مسی در اوایل بهار محلول‌پاشی کنید",
                "از تراکم زیاد بوته‌ها خودداری کنید تا تهویه بهتر شود"
            ), priority = 3
        ),

        // آجیلی
        DiseaseEntity(
            category = TreeCategory.NUT, nameFa = "آنتراکنوز گردو",
            shortDescription = "لکه‌های قهوه‌ای تیره روی برگ و میوه گردو.",
            imageRes = "disease_anthracnose",
            solutionSteps = listOf(
                "شاخه و برگ آلوده را هرس و معدوم کنید",
                "در بهار قارچ‌کش مسی محلول‌پاشی کنید",
                "زهکشی مناسب خاک را تضمین کنید"
            ), priority = 2
        ),
        DiseaseEntity(
            category = TreeCategory.NUT, nameFa = "پوسیدگی خشک پسته",
            shortDescription = "خشکیدگی خوشه و میوه پسته در اثر قارچ در هوای مرطوب.",
            imageRes = "disease_dryrot",
            solutionSteps = listOf(
                "خوشه‌های آلوده را حذف و معدوم کنید",
                "کوددهی ازته را متعادل نگه دارید",
                "در صورت رطوبت بالا قارچ‌کش مناسب طبق دستور کارشناس استفاده کنید"
            ), priority = 2
        ),

        // مرکبات
        DiseaseEntity(
            category = TreeCategory.CITRUS, nameFa = "جرب مرکبات",
            shortDescription = "برجستگی‌های زگیل‌مانند روی پوست میوه و برگ.",
            imageRes = "disease_citrus_scab",
            solutionSteps = listOf(
                "شاخه و برگ‌های آلوده را هرس کنید",
                "قارچ‌کش مسی بعد از ریزش گلبرگ محلول‌پاشی کنید",
                "از آبیاری بارانی مستقیم روی شاخ‌وبرگ پرهیز کنید"
            ), priority = 3
        ),
        DiseaseEntity(
            category = TreeCategory.CITRUS, nameFa = "گموز مرکبات (پوسیدگی طوقه)",
            shortDescription = "ترشح صمغ و پوسیدگی در ناحیه طوقه نزدیک خاک.",
            imageRes = "disease_citrus_gummosis",
            solutionSteps = listOf(
                "خاک اطراف طوقه را باز کرده و اجازه دهید خشک شود",
                "بافت پوسیده را با چاقوی تمیز خارج کنید",
                "قارچ‌کش مسی روی زخم بمالید",
                "از آبیاری مستقیم به تنه خودداری کنید"
            ), priority = 1
        ),

        // زیتون
        DiseaseEntity(
            category = TreeCategory.OLIVE, nameFa = "پیچیدگی و لکه برگی زیتون (پیکنوسپورا)",
            shortDescription = "لکه‌های حلقوی خاکستری روی برگ زیتون.",
            imageRes = "disease_olive_spot",
            solutionSteps = listOf(
                "برگ‌های ریخته‌شده را جمع‌آوری و معدوم کنید",
                "قارچ‌کش مسی در پاییز و اوایل بهار بزنید",
                "هرس برای تهویه بهتر انجام دهید"
            ), priority = 3
        ),
        DiseaseEntity(
            category = TreeCategory.SPECIAL, nameFa = "زنگ زرد انجیر",
            shortDescription = "لکه‌های زرد پودری در زیر برگ که باعث ریزش زودرس می‌شود.",
            imageRes = "disease_fig_rust",
            solutionSteps = listOf(
                "برگ‌های آلوده را جمع‌آوری و معدوم کنید",
                "از آبیاری روی برگ خودداری کنید",
                "قارچ‌کش مسی در صورت شیوع شدید استفاده کنید"
            ), priority = 3
        ),

        // نخل
        DiseaseEntity(
            category = TreeCategory.PALM, nameFa = "پوسیدگی قلب نخل",
            shortDescription = "پوسیدگی مرکز تاج نخل که رشد برگ‌های جدید را متوقف می‌کند.",
            imageRes = "disease_palm_rot",
            solutionSteps = listOf(
                "بافت پوسیده را با ابزار تمیز خارج کنید",
                "قارچ‌کش سیستمیک طبق دستور کارشناس محلی استفاده کنید",
                "زهکشی خاک را بهبود دهید تا آب راکد نماند"
            ), priority = 1
        )
    )
}

package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

enum class ActivityType(val displayNameFa: String) {
    WATERING("آبیاری"),
    FERTILIZING("کوددهی"),
    PESTICIDE("سم‌پاشی"),
    GRAFTING("پیوند"),
    PRUNING("هرس"),
    OTHER("سایر")
}

@Entity(
    tableName = "activities",
    foreignKeys = [
        ForeignKey(
            entity = TreeEntity::class,
            parentColumns = ["id"],
            childColumns = ["treeId"],
            onDelete = androidx.room.ForeignKey.CASCADE
        )
    ]
)
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val treeId: Long,
    val type: ActivityType,
    val date: Long,                     // تاریخ (میلادی timestamp، در UI به شمسی تبدیل می‌شود)
    val description: String = "",
    val imageBeforeUri: String? = null,
    val imageAfterUri: String? = null,
    val isCompleted: Boolean = false,    // false = برنامه‌ریزی‌شده در آینده، true = انجام‌شده
    val isFutureReminder: Boolean = false
)

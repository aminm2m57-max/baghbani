package com.baghbani.hooshmand.ui.screens.garden

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.util.PersianNumbers
import com.baghbani.hooshmand.util.ShamsiDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GardenManagementScreen(
    repository: GardenRepository,
    onBack: () -> Unit
) {
    val viewModel: GardenManagementViewModel = viewModel(
        factory = viewModelFactory { initializer { GardenManagementViewModel(repository) } }
    )
    val upcoming by viewModel.upcomingActivities.collectAsState()
    val allActivities by viewModel.allActivities.collectAsState()
    val priorityDiseases by viewModel.priorityDiseases.collectAsState()
    val priorityPests by viewModel.priorityPests.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("تقویم فعالیت‌ها", "بیماری و آفت", "آمار رشد")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مدیریت باغ") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { Text("فعالیت‌های آینده", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    if (upcoming.isEmpty()) {
                        item { Text("فعالیت آینده‌ای ثبت نشده است.") }
                    }
                    items(upcoming) { act ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Icon(activityIcon(act.type.name), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(act.type.displayNameFa, style = MaterialTheme.typography.titleMedium)
                                    Text(ShamsiDate.formatTimestamp(act.date), style = MaterialTheme.typography.bodyMedium)
                                    if (act.description.isNotBlank()) Text(act.description, style = MaterialTheme.typography.bodyMedium)
                                }
                                TextButton(onClick = { viewModel.markCompleted(act) }) { Text("انجام شد") }
                            }
                        }
                    }
                    item { Divider(modifier = Modifier.padding(vertical = 10.dp)) }
                    item { Text("تاریخچه فعالیت‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(allActivities.filter { it.isCompleted }) { act ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(act.type.displayNameFa, style = MaterialTheme.typography.titleMedium)
                                Text(ShamsiDate.formatTimestamp(act.date), style = MaterialTheme.typography.bodyMedium)
                                if (act.description.isNotBlank()) Text(act.description, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                1 -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { Text("بیماری‌های شایع (اولویت‌بندی‌شده)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(priorityDiseases) { d ->
                        ListItem(
                            headlineContent = { Text(d.nameFa) },
                            supportingContent = { Text(d.shortDescription) },
                            leadingContent = {
                                Text(
                                    when (d.priority) { 1 -> "بحرانی"; 2 -> "متوسط"; else -> "کم‌خطر" },
                                    color = if (d.priority == 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }
                    item { Divider(modifier = Modifier.padding(vertical = 10.dp)) }
                    item { Text("آفات شایع (اولویت‌بندی‌شده)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(priorityPests) { p ->
                        ListItem(
                            headlineContent = { Text(p.nameFa) },
                            supportingContent = { Text(p.shortDescription) },
                            leadingContent = {
                                Text(
                                    when (p.priority) { 1 -> "بحرانی"; 2 -> "متوسط"; else -> "کم‌خطر" },
                                    color = if (p.priority == 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }
                }

                2 -> Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    Text(
                        "برای مشاهده آمار رشد سالانه هر درخت، وارد صفحه جزئیات همان درخت شوید و رکورد رشد سالانه ثبت کنید.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}

private fun activityIcon(typeName: String) = when (typeName) {
    "WATERING" -> Icons.Filled.WaterDrop
    "FERTILIZING" -> Icons.Filled.Grass
    "PESTICIDE" -> Icons.Filled.BugReport
    "GRAFTING" -> Icons.Filled.AccountTree
    "PRUNING" -> Icons.Filled.ContentCut
    else -> Icons.Filled.Event
}

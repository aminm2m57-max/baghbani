package com.baghbani.hooshmand.data.local.dao

import androidx.room.*
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TreeSpeciesDao {

    @Query("SELECT * FROM tree_species ORDER BY nameFa ASC")
    fun getAllSpecies(): Flow<List<TreeSpeciesEntity>>

    @Query("SELECT * FROM tree_species WHERE id = :id")
    suspend fun getSpeciesById(id: Long): TreeSpeciesEntity?

    @Query("SELECT COUNT(*) FROM tree_species")
    suspend fun countSpecies(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(species: List<TreeSpeciesEntity>)

    @Update
    suspend fun update(species: TreeSpeciesEntity)
}

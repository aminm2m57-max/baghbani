package com.baghbani.hooshmand

import android.app.Application
import com.baghbani.hooshmand.data.datastore.SettingsDataStore
import com.baghbani.hooshmand.data.local.AppDatabase
import com.baghbani.hooshmand.data.repository.GardenRepository

class BaghbaniApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: GardenRepository
        private set

    lateinit var settingsDataStore: SettingsDataStore
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        repository = GardenRepository(database)
        settingsDataStore = SettingsDataStore(this)
    }
}

package com.baghbani.hooshmand

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.baghbani.hooshmand.ui.navigation.BaghbaniNavHost
import com.baghbani.hooshmand.ui.theme.BaghbaniHooshmandTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as BaghbaniApp

        setContent {
            val darkTheme by app.settingsDataStore.isDarkTheme.collectAsState(initial = false)

            BaghbaniHooshmandTheme(darkTheme = darkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BaghbaniNavHost(
                        repository = app.repository,
                        settingsDataStore = app.settingsDataStore
                    )
                }
            }
        }
    }
}

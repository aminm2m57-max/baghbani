package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "diseases")
data class DiseaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val category: TreeCategory,         // این بیماری برای کدام دسته درخت است
    val nameFa: String,
    val shortDescription: String,
    val imageRes: String,
    val solutionSteps: List<String>,    // راه‌حل گام‌به‌گام (با TypeConverter ذخیره می‌شود)
    val priority: Int = 2                // ۱=بحرانی، ۲=متوسط، ۳=کم‌خطر — برای اولویت‌بندی در مدیریت باغ
)

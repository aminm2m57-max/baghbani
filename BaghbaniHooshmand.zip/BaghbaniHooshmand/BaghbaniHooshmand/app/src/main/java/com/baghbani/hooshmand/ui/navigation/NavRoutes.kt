package com.baghbani.hooshmand.ui.navigation

object NavRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val TREE_LIST = "tree_list"
    const val TREE_DETAIL = "tree_detail/{treeId}"
    const val ADD_TREE = "add_tree"
    const val GARDEN_MANAGEMENT = "garden_management"
    const val GENERAL_INFO = "general_info"
    const val SETTINGS = "settings"

    fun treeDetail(treeId: Long) = "tree_detail/$treeId"
}

package com.baghbani.hooshmand.ui.screens.treelist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.ui.components.TreeSummaryCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TreeListScreen(
    repository: GardenRepository,
    onTreeClick: (Long) -> Unit,
    onBack: () -> Unit
) {
    val viewModel: TreeListViewModel = viewModel(
        factory = viewModelFactory { initializer { TreeListViewModel(repository) } }
    )
    val trees by viewModel.trees.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("لیست تمام گیاهان") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(trees) { item ->
                TreeSummaryCard(item = item, onClick = { onTreeClick(item.tree.id) })
            }
            if (trees.isEmpty()) {
                item { Text("هنوز درختی ثبت نشده است.") }
            }
        }
    }
}

package com.baghbani.hooshmand.ui.screens.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.datastore.SettingsDataStore
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.data.seed.DiseaseSeed
import com.baghbani.hooshmand.data.seed.GraftMethodSeed
import com.baghbani.hooshmand.data.seed.PestSeed
import com.baghbani.hooshmand.data.seed.SpeciesSeed
import kotlinx.coroutines.launch

/**
 * صفحه معرفی اول اجرا: کاتالوگ مرجع (گونه‌ها، بیماری‌ها، آفات، پیوندها) را فقط یک‌بار Seed می‌کند.
 * بعد از تکمیل، دیگر هیچ‌وقت نمایش داده نمی‌شود مگر کاربر از تنظیمات بازنشانی کند.
 */
class OnboardingViewModel(
    private val repository: GardenRepository,
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    fun completeOnboarding(onDone: () -> Unit) {
        viewModelScope.launch {
            if (!repository.isCatalogSeeded()) {
                repository.seedCatalog(
                    species = SpeciesSeed.list(),
                    diseases = DiseaseSeed.list(),
                    pests = PestSeed.list(),
                    graftMethods = GraftMethodSeed.list()
                )
            }
            settingsDataStore.setOnboardingDone(true)
            onDone()
        }
    }
}

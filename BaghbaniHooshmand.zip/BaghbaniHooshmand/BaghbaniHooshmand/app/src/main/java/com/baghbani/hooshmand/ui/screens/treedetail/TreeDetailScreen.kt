package com.baghbani.hooshmand.ui.screens.treedetail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.AsyncImage
import com.baghbani.hooshmand.data.repository.GardenRepository
import com.baghbani.hooshmand.ui.components.ExpandableSection
import com.baghbani.hooshmand.ui.components.HealthStatusChip
import com.baghbani.hooshmand.ui.components.IconLabelRow
import com.baghbani.hooshmand.ui.components.StepsList
import com.baghbani.hooshmand.util.PersianNumbers

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TreeDetailScreen(
    repository: GardenRepository,
    treeId: Long,
    onBack: () -> Unit
) {
    val viewModel: TreeDetailViewModel = viewModel(
        factory = viewModelFactory { initializer { TreeDetailViewModel(repository, treeId) } }
    )
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.species?.nameFa ?: "جزئیات درخت") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        if (state.isLoading || state.species == null || state.tree == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val species = state.species!!
        val tree = state.tree!!

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // ---------- عنوان و تصویر ----------
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
            ) {
                AsyncImage(model = tree.imageUri, contentDescription = species.nameFa, modifier = Modifier.fillMaxSize())
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(species.nameFa, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(species.scientificName, style = MaterialTheme.typography.bodyMedium)
                }
                HealthStatusChip(status = tree.healthStatus)
            }
            Spacer(modifier = Modifier.height(12.dp))

            // ---------- اطلاعات پایه ----------
            ExpandableSection(title = "اطلاعات پایه", icon = Icons.Filled.Info, initiallyExpanded = true) {
                IconLabelRow(Icons.Filled.Cake, "عمر درخت", "${PersianNumbers.toPersian(tree.ageYears)} سال")
                IconLabelRow(Icons.Filled.Park, "عمر متوسط گونه", species.avgLifespanYears)
                IconLabelRow(Icons.Filled.Height, "اندازه", species.sizeInfo)
                IconLabelRow(Icons.Filled.TrendingUp, "رشد سالانه", species.annualGrowthRate)
                IconLabelRow(Icons.Filled.WbSunny, "نیاز به نور", species.lightNeed)
            }

            // ---------- آبیاری ----------
            ExpandableSection(title = "آبیاری", icon = Icons.Filled.WaterDrop) {
                IconLabelRow(Icons.Filled.Opacity, "مقدار", species.wateringAmount)
                IconLabelRow(Icons.Filled.Schedule, "دوره", species.wateringFrequency)
                IconLabelRow(Icons.Filled.Build, "روش", species.wateringMethod)
            }

            // ---------- کوددهی ----------
            ExpandableSection(title = "کوددهی", icon = Icons.Filled.Grass) {
                IconLabelRow(Icons.Filled.Category, "نوع کود", species.fertilizerType)
                IconLabelRow(Icons.Filled.Scale, "دوز مصرف", species.fertilizerDose)
                IconLabelRow(Icons.Filled.Schedule, "زمان‌بندی", species.fertilizerSchedule)
            }

            // ---------- سم‌پاشی ----------
            ExpandableSection(title = "سم‌پاشی", icon = Icons.Filled.BugReport) {
                IconLabelRow(Icons.Filled.Science, "نوع سم", species.pesticideType)
                IconLabelRow(Icons.Filled.Scale, "دوز مصرف", species.pesticideDose)
                IconLabelRow(Icons.Filled.Schedule, "زمان‌بندی", species.pesticideSchedule)
            }

            // ---------- بیماری‌های شایع ----------
            ExpandableSection(title = "بیماری‌های شایع (${PersianNumbers.toPersian(state.diseases.size)})", icon = Icons.Filled.Coronavirus) {
                if (state.diseases.isEmpty()) {
                    Text("بیماری شایع خاصی برای این گروه ثبت نشده است.")
                }
                state.diseases.forEach { disease ->
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        Text(disease.nameFa, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(disease.shortDescription, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("راه‌حل گام‌به‌گام:", style = MaterialTheme.typography.labelLarge)
                        StepsList(disease.solutionSteps)
                    }
                    Divider(modifier = Modifier.padding(vertical = 6.dp))
                }
            }

            // ---------- آفات و حشرات ----------
            ExpandableSection(title = "آفات و حشرات (${PersianNumbers.toPersian(state.pests.size)})", icon = Icons.Filled.PestControl) {
                if (state.pests.isEmpty()) {
                    Text("آفت شایع خاصی برای این گروه ثبت نشده است.")
                }
                state.pests.forEach { pest ->
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        Text(pest.nameFa, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(pest.shortDescription, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("راه‌حل گام‌به‌گام:", style = MaterialTheme.typography.labelLarge)
                        StepsList(pest.solutionSteps)
                    }
                    Divider(modifier = Modifier.padding(vertical = 6.dp))
                }
            }

            // ---------- پیوند ----------
            ExpandableSection(title = "روش‌های پیوند (${PersianNumbers.toPersian(state.graftMethods.size)})", icon = Icons.Filled.AccountTree) {
                if (state.graftMethods.isEmpty()) {
                    Text("روش پیوند رایج و متداولی برای این درخت ثبت نشده است.")
                }
                state.graftMethods.forEach { graft ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(graft.nameFa, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            IconLabelRow(Icons.Filled.CalendarMonth, "زمان مناسب", graft.bestSeason)
                            IconLabelRow(Icons.Filled.Thermostat, "دمای ایده‌آل", graft.idealTemperature)
                            IconLabelRow(Icons.Filled.CheckCircle, "نرخ موفقیت تقریبی", "${PersianNumbers.toPersian(graft.approxSuccessRate)}٪")
                            IconLabelRow(Icons.Filled.BeachAccess, "نیاز به سایه", if (graft.shadeNeeded) "بله" else "خیر")
                            IconLabelRow(Icons.Filled.Event, "روزهای مراقبت اول", "${PersianNumbers.toPersian(graft.firstDaysCareCount)} روز")

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("روش انجام:", style = MaterialTheme.typography.labelLarge)
                            StepsList(graft.procedureSteps)

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("مواد و ابزار مورد نیاز:", style = MaterialTheme.typography.labelLarge)
                            graft.requiredTools.forEach { tool -> Text("• $tool", style = MaterialTheme.typography.bodyMedium) }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("مراقبت بعد از پیوند:", style = MaterialTheme.typography.labelLarge)
                            Text(graft.aftercareInfo, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // ---------- یادداشت شخصی ----------
            ExpandableSection(title = "یادداشت‌های شخصی", icon = Icons.Filled.EditNote, initiallyExpanded = true) {
                var notes by remember(tree.id) { mutableStateOf(tree.personalNotes) }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    label = { Text("یادداشت خودتان را اینجا بنویسید...") }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = { viewModel.updateNotes(notes) }, modifier = Modifier.align(androidx.compose.ui.Alignment.End)) {
                    Text("ذخیره یادداشت")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

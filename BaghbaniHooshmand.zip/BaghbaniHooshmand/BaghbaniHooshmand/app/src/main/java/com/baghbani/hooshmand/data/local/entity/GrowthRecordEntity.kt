package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "growth_records",
    foreignKeys = [
        ForeignKey(
            entity = TreeEntity::class,
            parentColumns = ["id"],
            childColumns = ["treeId"],
            onDelete = androidx.room.ForeignKey.CASCADE
        )
    ]
)
data class GrowthRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val treeId: Long,
    val year: Int,               // سال شمسی
    val heightCm: Int? = null,
    val note: String = ""
)

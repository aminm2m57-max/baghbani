package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "graft_methods")
data class GraftMethodEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val category: TreeCategory,          // این نوع پیوند فقط برای این دسته درخت‌ها معتبر است
    val nameFa: String,                  // مثلاً "پیوند شکمی انار"
    val bestSeason: String,              // موسم مناسب
    val idealTemperature: String,        // دمای ایده‌آل
    val procedureSteps: List<String>,    // روش انجام گام‌به‌گام
    val requiredTools: List<String>,     // ابزار و مواد لازم
    val aftercareInfo: String,           // مراقبت بعد از پیوند
    val shadeNeeded: Boolean,            // آیا سایه لازم دارد
    val firstDaysCareCount: Int,         // تعداد روزهای مراقبت ویژه اول
    val approxSuccessRate: Int           // نرخ موفقیت تقریبی (٪)
)

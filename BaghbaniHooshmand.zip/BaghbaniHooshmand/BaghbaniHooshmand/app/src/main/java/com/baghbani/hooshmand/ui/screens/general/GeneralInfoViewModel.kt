package com.baghbani.hooshmand.ui.screens.general

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity
import com.baghbani.hooshmand.data.repository.GardenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class GeneralInfoViewModel(repository: GardenRepository) : ViewModel() {
    val allSpecies: StateFlow<List<TreeSpeciesEntity>> =
        repository.getAllSpecies().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

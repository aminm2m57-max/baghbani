package com.baghbani.hooshmand.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * داده‌های مرجع و ثابت هر گونه درخت (کاتالوگ عمومی باغبانی).
 * این جدول مستقل از درخت‌های واقعی کاربر است و در اولین اجرای اپ Seed می‌شود.
 */
@Entity(tableName = "tree_species")
data class TreeSpeciesEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val nameFa: String,
    val scientificName: String,
    val category: TreeCategory,
    val imageRes: String,               // نام drawable یا مسیر تصویر پیش‌فرض

    // اطلاعات پایه
    val avgLifespanYears: String,       // مثلاً "۵۰ تا ۸۰ سال"
    val sizeInfo: String,               // اندازه بالغ درخت
    val annualGrowthRate: String,       // رشد سالانه
    val lightNeed: String,              // نیاز نوری

    // آبیاری
    val wateringAmount: String,
    val wateringFrequency: String,
    val wateringMethod: String,

    // کوددهی
    val fertilizerType: String,
    val fertilizerDose: String,
    val fertilizerSchedule: String,

    // سم‌پاشی
    val pesticideType: String,
    val pesticideDose: String,
    val pesticideSchedule: String
)

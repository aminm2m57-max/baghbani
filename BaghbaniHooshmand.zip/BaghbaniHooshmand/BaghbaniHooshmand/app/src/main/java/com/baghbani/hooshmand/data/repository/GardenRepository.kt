package com.baghbani.hooshmand.data.repository

import com.baghbani.hooshmand.data.local.AppDatabase
import com.baghbani.hooshmand.data.local.entity.*
import kotlinx.coroutines.flow.Flow

/**
 * لایه واسط بین ViewModel ها و Room Database.
 * تمام دسترسی به داده باید از طریق این کلاس انجام شود.
 */
class GardenRepository(private val db: AppDatabase) {

    // ---------- گونه‌های مرجع ----------
    fun getAllSpecies(): Flow<List<TreeSpeciesEntity>> = db.treeSpeciesDao().getAllSpecies()
    suspend fun getSpeciesById(id: Long): TreeSpeciesEntity? = db.treeSpeciesDao().getSpeciesById(id)

    // ---------- درخت‌های کاربر ----------
    fun getAllTrees(): Flow<List<TreeEntity>> = db.treeDao().getAllTrees()
    fun getTreeById(id: Long): Flow<TreeEntity?> = db.treeDao().getTreeById(id)
    fun getTreeCount(): Flow<Int> = db.treeDao().getTreeCount()
    fun getHealthyCount(): Flow<Int> = db.treeDao().getHealthyCount()
    fun getDiseasedCount(): Flow<Int> = db.treeDao().getDiseasedCount()
    fun getPestAffectedCount(): Flow<Int> = db.treeDao().getPestAffectedCount()

    suspend fun addTree(tree: TreeEntity): Long = db.treeDao().insert(tree)
    suspend fun updateTree(tree: TreeEntity) = db.treeDao().update(tree)
    suspend fun deleteTree(tree: TreeEntity) = db.treeDao().delete(tree)
    suspend fun updateTreeNotes(treeId: Long, notes: String) = db.treeDao().updateNotes(treeId, notes)

    // ---------- بیماری‌ها / آفات / پیوند (بر اساس دسته درخت) ----------
    fun getDiseasesForCategory(category: TreeCategory): Flow<List<DiseaseEntity>> =
        db.diseaseDao().getDiseasesForCategory(category)

    fun getPestsForCategory(category: TreeCategory): Flow<List<PestEntity>> =
        db.pestDao().getPestsForCategory(category)

    fun getGraftMethodsForCategory(category: TreeCategory): Flow<List<GraftMethodEntity>> =
        db.graftMethodDao().getGraftMethodsForCategory(category)

    fun getAllDiseasesSortedByPriority(): Flow<List<DiseaseEntity>> =
        db.diseaseDao().getAllDiseasesSortedByPriority()

    fun getAllPestsSortedByPriority(): Flow<List<PestEntity>> =
        db.pestDao().getAllPestsSortedByPriority()

    // ---------- فعالیت‌ها / تقویم مدیریت باغ ----------
    fun getAllActivities(): Flow<List<ActivityEntity>> = db.activityDao().getAllActivities()
    fun getActivitiesForTree(treeId: Long): Flow<List<ActivityEntity>> =
        db.activityDao().getActivitiesForTree(treeId)
    fun getUpcomingActivities(): Flow<List<ActivityEntity>> = db.activityDao().getUpcomingActivities()

    suspend fun addActivity(activity: ActivityEntity): Long = db.activityDao().insert(activity)
    suspend fun updateActivity(activity: ActivityEntity) = db.activityDao().update(activity)
    suspend fun deleteActivity(activity: ActivityEntity) = db.activityDao().delete(activity)

    // ---------- آمار رشد ----------
    fun getGrowthRecordsForTree(treeId: Long): Flow<List<GrowthRecordEntity>> =
        db.growthRecordDao().getGrowthRecordsForTree(treeId)

    suspend fun addGrowthRecord(record: GrowthRecordEntity): Long =
        db.growthRecordDao().insert(record)

    // ---------- Seed check ----------
    suspend fun isCatalogSeeded(): Boolean =
        db.treeSpeciesDao().countSpecies() > 0 &&
        db.diseaseDao().count() > 0 &&
        db.pestDao().count() > 0 &&
        db.graftMethodDao().count() > 0

    suspend fun seedCatalog(
        species: List<TreeSpeciesEntity>,
        diseases: List<DiseaseEntity>,
        pests: List<PestEntity>,
        graftMethods: List<GraftMethodEntity>
    ) {
        db.treeSpeciesDao().insertAll(species)
        db.diseaseDao().insertAll(diseases)
        db.pestDao().insertAll(pests)
        db.graftMethodDao().insertAll(graftMethods)
    }
}

package com.baghbani.hooshmand.data.seed

import com.baghbani.hooshmand.data.local.entity.TreeCategory
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity

/**
 * داده مرجع ۲۰ گونه درخت رایج باغبانی ایران — فقط یک‌بار در اولین اجرای اپ در Room ذخیره می‌شود.
 */
object SpeciesSeed {

    fun list(): List<TreeSpeciesEntity> = listOf(
        TreeSpeciesEntity(
            nameFa = "سیب", scientificName = "Malus domestica", category = TreeCategory.POME_FRUIT,
            imageRes = "tree_apple", avgLifespanYears = "۵۰ تا ۸۰ سال", sizeInfo = "۳ تا ۶ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۶۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل (حداقل ۶ ساعت روزانه)",
            wateringAmount = "۳۰ تا ۴۰ لیتر برای هر درخت بالغ", wateringFrequency = "هر ۷ تا ۱۰ روز در فصل رشد",
            wateringMethod = "آبیاری قطره‌ای یا نشتی دور تنه",
            fertilizerType = "کود کامل NPK + کود دامی پوسیده", fertilizerDose = "۲ تا ۳ کیلوگرم کود دامی + ۲۰۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار و اواخر تابستان",
            pesticideType = "روغن ولک زمستانه + قارچ‌کش مسی", pesticideDose = "طبق دستور برچسب محصول",
            pesticideSchedule = "پیش از باز شدن جوانه‌ها در اسفند"
        ),
        TreeSpeciesEntity(
            nameFa = "گلابی", scientificName = "Pyrus communis", category = TreeCategory.POME_FRUIT,
            imageRes = "tree_pear", avgLifespanYears = "۵۰ تا ۷۵ سال", sizeInfo = "۴ تا ۷ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۵ تا ۳۵ لیتر برای هر درخت بالغ", wateringFrequency = "هر ۷ تا ۱۰ روز در فصل رشد",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "کود کامل NPK + کود دامی پوسیده", fertilizerDose = "۲ کیلوگرم کود دامی + ۱۵۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "روغن ولک زمستانه + قارچ‌کش", pesticideDose = "طبق دستور برچسب",
            pesticideSchedule = "اسفند و اوایل فروردین"
        ),
        TreeSpeciesEntity(
            nameFa = "به", scientificName = "Cydonia oblonga", category = TreeCategory.POME_FRUIT,
            imageRes = "tree_quince", avgLifespanYears = "۴۰ تا ۶۰ سال", sizeInfo = "۳ تا ۵ متر ارتفاع",
            annualGrowthRate = "۲۵ تا ۴۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۰ تا ۳۰ لیتر", wateringFrequency = "هر ۱۰ روز در فصل رشد",
            wateringMethod = "آبیاری غرقابی سبک",
            fertilizerType = "کود دامی پوسیده", fertilizerDose = "۲ کیلوگرم",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "اسفند"
        ),
        TreeSpeciesEntity(
            nameFa = "هلو", scientificName = "Prunus persica", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_peach", avgLifespanYears = "۱۵ تا ۲۵ سال", sizeInfo = "۳ تا ۵ متر ارتفاع",
            annualGrowthRate = "۴۰ تا ۷۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۵ تا ۳۵ لیتر", wateringFrequency = "هر ۵ تا ۷ روز در تابستان",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "NPK متعادل + کود دامی", fertilizerDose = "۲۵۰ گرم NPK + ۲ کیلوگرم کود دامی",
            fertilizerSchedule = "اوایل بهار و بعد از برداشت میوه",
            pesticideType = "قارچ‌کش مسی (پیچیدگی برگ) + حشره‌کش", pesticideDose = "طبق برچسب",
            pesticideSchedule = "قبل از باز شدن جوانه و بعد از ریزش گلبرگ"
        ),
        TreeSpeciesEntity(
            nameFa = "زردآلو", scientificName = "Prunus armeniaca", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_apricot", avgLifespanYears = "۲۰ تا ۴۰ سال", sizeInfo = "۴ تا ۶ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۵ تا ۳۰ لیتر", wateringFrequency = "هر ۷ روز در تابستان",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "NPK + کود دامی", fertilizerDose = "۲۰۰ گرم NPK + ۲ کیلوگرم دامی",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "زمستان و پیش از گلدهی"
        ),
        TreeSpeciesEntity(
            nameFa = "آلو", scientificName = "Prunus domestica", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_plum", avgLifespanYears = "۲۰ تا ۳۰ سال", sizeInfo = "۳ تا ۶ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۵ لیتر", wateringFrequency = "هر ۷ تا ۱۰ روز",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "NPK + کود دامی", fertilizerDose = "۲۰۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "زمستان"
        ),
        TreeSpeciesEntity(
            nameFa = "گیلاس", scientificName = "Prunus avium", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_cherry", avgLifespanYears = "۲۵ تا ۴۰ سال", sizeInfo = "۵ تا ۸ متر ارتفاع",
            annualGrowthRate = "۴۰ تا ۶۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۳۰ لیتر", wateringFrequency = "هر ۷ روز در تابستان",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "NPK + کود دامی", fertilizerDose = "۲۵۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "زمستان و پیش از گلدهی"
        ),
        TreeSpeciesEntity(
            nameFa = "آلبالو", scientificName = "Prunus cerasus", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_sourcherry", avgLifespanYears = "۲۰ تا ۳۵ سال", sizeInfo = "۳ تا ۵ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل تا نیمه‌سایه",
            wateringAmount = "۲۵ لیتر", wateringFrequency = "هر ۷ تا ۱۰ روز",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "NPK + کود دامی", fertilizerDose = "۲۰۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "زمستان"
        ),
        TreeSpeciesEntity(
            nameFa = "بادام", scientificName = "Prunus dulcis", category = TreeCategory.STONE_FRUIT,
            imageRes = "tree_almond", avgLifespanYears = "۲۵ تا ۵۰ سال", sizeInfo = "۴ تا ۸ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۰ تا ۳۰ لیتر", wateringFrequency = "هر ۱۰ تا ۱۴ روز (مقاوم به خشکی)",
            wateringMethod = "آبیاری قطره‌ای یا دیم در مناطق مناسب",
            fertilizerType = "NPK + کود دامی", fertilizerDose = "۲۰۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "زمستان"
        ),
        TreeSpeciesEntity(
            nameFa = "انگور", scientificName = "Vitis vinifera", category = TreeCategory.VINE,
            imageRes = "tree_grape", avgLifespanYears = "۳۰ تا ۶۰ سال", sizeInfo = "بوته تاکی، نیازمند داربست",
            annualGrowthRate = "رشد شاخه تا ۲ تا ۳ متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۱۵ تا ۲۵ لیتر", wateringFrequency = "هر ۱۰ تا ۱۴ روز",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "کود پتاسه + کود دامی", fertilizerDose = "۱۵۰ گرم پتاسه + ۲ کیلوگرم دامی",
            fertilizerSchedule = "اوایل بهار و قبل از گلدهی",
            pesticideType = "گوگرد پودری (سفیدک) + قارچ‌کش", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار تا اواسط تابستان هر ۱۵ روز"
        ),
        TreeSpeciesEntity(
            nameFa = "انار", scientificName = "Punica granatum", category = TreeCategory.POMEGRANATE,
            imageRes = "tree_pomegranate", avgLifespanYears = "۵۰ تا ۱۰۰ سال", sizeInfo = "۲ تا ۵ متر ارتفاع (بوته‌ای)",
            annualGrowthRate = "۴۰ تا ۶۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۰ تا ۳۰ لیتر", wateringFrequency = "هر ۱۰ تا ۱۵ روز",
            wateringMethod = "آبیاری غرقابی یا قطره‌ای",
            fertilizerType = "کود دامی پوسیده + کود پتاسه", fertilizerDose = "۳ کیلوگرم دامی + ۱۵۰ گرم پتاسه",
            fertilizerSchedule = "اواخر زمستان",
            pesticideType = "حشره‌کش برای کرم گلوگاه انار", pesticideDose = "طبق برچسب",
            pesticideSchedule = "اواخر بهار تا تابستان هر ۲۰ روز"
        ),
        TreeSpeciesEntity(
            nameFa = "پسته", scientificName = "Pistacia vera", category = TreeCategory.NUT,
            imageRes = "tree_pistachio", avgLifespanYears = "۱۰۰ تا ۳۰۰ سال", sizeInfo = "۵ تا ۸ متر ارتفاع",
            annualGrowthRate = "۲۰ تا ۴۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، مقاوم به خشکی و شوری",
            wateringAmount = "۴۰ تا ۶۰ لیتر", wateringFrequency = "هر ۱۵ تا ۲۰ روز در تابستان",
            wateringMethod = "آبیاری غرقابی سنتی یا قطره‌ای",
            fertilizerType = "کود دامی پوسیده + کود فسفاته", fertilizerDose = "۵ کیلوگرم دامی + ۲۰۰ گرم فسفاته",
            fertilizerSchedule = "زمستان",
            pesticideType = "حشره‌کش برای پسیل پسته", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار و تابستان طبق پایش آفت"
        ),
        TreeSpeciesEntity(
            nameFa = "گردو", scientificName = "Juglans regia", category = TreeCategory.NUT,
            imageRes = "tree_walnut", avgLifespanYears = "۸۰ تا ۱۵۰ سال", sizeInfo = "۱۰ تا ۲۰ متر ارتفاع",
            annualGrowthRate = "۵۰ تا ۸۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۵۰ تا ۷۰ لیتر", wateringFrequency = "هر ۱۰ تا ۱۵ روز",
            wateringMethod = "آبیاری غرقابی",
            fertilizerType = "کود دامی + NPK", fertilizerDose = "۵ کیلوگرم دامی + ۳۰۰ گرم NPK",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "قارچ‌کش مسی (آنتراکنوز)", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار"
        ),
        TreeSpeciesEntity(
            nameFa = "پرتقال", scientificName = "Citrus sinensis", category = TreeCategory.CITRUS,
            imageRes = "tree_orange", avgLifespanYears = "۵۰ تا ۸۰ سال", sizeInfo = "۳ تا ۵ متر ارتفاع",
            annualGrowthRate = "۲۵ تا ۴۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، حساس به سرما",
            wateringAmount = "۲۰ تا ۳۰ لیتر", wateringFrequency = "هر ۵ تا ۷ روز در تابستان",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "کود کامل مرکبات (ریزمغذی+آهن)", fertilizerDose = "طبق برچسب، معمولاً ماهانه در فصل رشد",
            fertilizerSchedule = "بهار تا پاییز هر ۴۵ روز",
            pesticideType = "روغن باغی برای شپشک", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار و تابستان"
        ),
        TreeSpeciesEntity(
            nameFa = "لیمو ترش", scientificName = "Citrus aurantifolia", category = TreeCategory.CITRUS,
            imageRes = "tree_lime", avgLifespanYears = "۳۰ تا ۵۰ سال", sizeInfo = "۲ تا ۴ متر ارتفاع",
            annualGrowthRate = "۲۵ تا ۴۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، بسیار حساس به سرما",
            wateringAmount = "۱۵ تا ۲۵ لیتر", wateringFrequency = "هر ۵ روز در تابستان",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "کود کامل مرکبات", fertilizerDose = "طبق برچسب هر ۴۵ روز",
            fertilizerSchedule = "بهار تا پاییز",
            pesticideType = "روغن باغی + حشره‌کش شپشک", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار و تابستان"
        ),
        TreeSpeciesEntity(
            nameFa = "نارنگی", scientificName = "Citrus reticulata", category = TreeCategory.CITRUS,
            imageRes = "tree_tangerine", avgLifespanYears = "۴۰ تا ۶۰ سال", sizeInfo = "۲ تا ۴ متر ارتفاع",
            annualGrowthRate = "۲۵ تا ۳۵ سانتی‌متر در سال", lightNeed = "آفتاب کامل، حساس به سرما",
            wateringAmount = "۲۰ لیتر", wateringFrequency = "هر ۵ تا ۷ روز",
            wateringMethod = "آبیاری قطره‌ای",
            fertilizerType = "کود کامل مرکبات", fertilizerDose = "طبق برچسب",
            fertilizerSchedule = "بهار تا پاییز هر ۴۵ روز",
            pesticideType = "روغن باغی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار و تابستان"
        ),
        TreeSpeciesEntity(
            nameFa = "زیتون", scientificName = "Olea europaea", category = TreeCategory.OLIVE,
            imageRes = "tree_olive", avgLifespanYears = "۱۰۰ تا ۵۰۰ سال", sizeInfo = "۴ تا ۸ متر ارتفاع",
            annualGrowthRate = "۲۰ تا ۳۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، بسیار مقاوم به خشکی",
            wateringAmount = "۲۰ تا ۳۰ لیتر", wateringFrequency = "هر ۱۵ تا ۲۰ روز",
            wateringMethod = "آبیاری قطره‌ای یا دیم",
            fertilizerType = "کود دامی + کود پتاسه", fertilizerDose = "۳ کیلوگرم دامی + ۱۵۰ گرم پتاسه",
            fertilizerSchedule = "اواخر زمستان",
            pesticideType = "تله فرومونی و حشره‌کش مگس زیتون", pesticideDose = "طبق برچسب",
            pesticideSchedule = "تابستان تا پاییز"
        ),
        TreeSpeciesEntity(
            nameFa = "انجیر", scientificName = "Ficus carica", category = TreeCategory.SPECIAL,
            imageRes = "tree_fig", avgLifespanYears = "۳۰ تا ۵۰ سال", sizeInfo = "۳ تا ۶ متر ارتفاع",
            annualGrowthRate = "۴۰ تا ۶۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل",
            wateringAmount = "۲۰ لیتر", wateringFrequency = "هر ۱۰ روز",
            wateringMethod = "آبیاری غرقابی سبک",
            fertilizerType = "کود دامی پوسیده", fertilizerDose = "۲ کیلوگرم",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "کنترل عمومی آفت با روغن باغی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "بهار"
        ),
        TreeSpeciesEntity(
            nameFa = "توت", scientificName = "Morus alba", category = TreeCategory.SPECIAL,
            imageRes = "tree_mulberry", avgLifespanYears = "۵۰ تا ۱۰۰ سال", sizeInfo = "۵ تا ۱۰ متر ارتفاع",
            annualGrowthRate = "۵۰ تا ۸۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، بسیار مقاوم",
            wateringAmount = "۳۰ لیتر", wateringFrequency = "هر ۱۰ تا ۱۵ روز",
            wateringMethod = "آبیاری غرقابی",
            fertilizerType = "کود دامی پوسیده", fertilizerDose = "۲ تا ۳ کیلوگرم",
            fertilizerSchedule = "اوایل بهار",
            pesticideType = "معمولاً نیاز کمی دارد؛ روغن باغی در صورت آلودگی", pesticideDose = "طبق برچسب",
            pesticideSchedule = "در صورت مشاهده آفت"
        ),
        TreeSpeciesEntity(
            nameFa = "خرما", scientificName = "Phoenix dactylifera", category = TreeCategory.PALM,
            imageRes = "tree_date_palm", avgLifespanYears = "۸۰ تا ۱۵۰ سال", sizeInfo = "تا ۲۰ متر ارتفاع",
            annualGrowthRate = "۳۰ تا ۵۰ سانتی‌متر در سال", lightNeed = "آفتاب کامل، مقاوم به گرما و خشکی",
            wateringAmount = "۶۰ تا ۱۰۰ لیتر", wateringFrequency = "هر ۷ تا ۱۰ روز در تابستان",
            wateringMethod = "آبیاری غرقابی یا نشتی",
            fertilizerType = "کود دامی پوسیده + پتاسه", fertilizerDose = "۱۰ کیلوگرم دامی + ۳۰۰ گرم پتاسه",
            fertilizerSchedule = "بهار",
            pesticideType = "کنترل سوسک سرخرطومی حنایی", pesticideDose = "طبق دستور کارشناس",
            pesticideSchedule = "پایش مستمر در طول سال"
        )
    )
}

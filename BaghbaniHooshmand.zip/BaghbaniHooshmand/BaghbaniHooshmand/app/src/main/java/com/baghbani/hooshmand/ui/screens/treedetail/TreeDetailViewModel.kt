package com.baghbani.hooshmand.ui.screens.treedetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.local.entity.*
import com.baghbani.hooshmand.data.repository.GardenRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TreeDetailUiState(
    val tree: TreeEntity? = null,
    val species: TreeSpeciesEntity? = null,
    val diseases: List<DiseaseEntity> = emptyList(),
    val pests: List<PestEntity> = emptyList(),
    val graftMethods: List<GraftMethodEntity> = emptyList(),
    val isLoading: Boolean = true
)

class TreeDetailViewModel(
    private val repository: GardenRepository,
    private val treeId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(TreeDetailUiState())
    val uiState: StateFlow<TreeDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getTreeById(treeId).collect { tree ->
                if (tree != null) {
                    val species = repository.getSpeciesById(tree.speciesId)
                    if (species != null) {
                        launch {
                            combine(
                                repository.getDiseasesForCategory(species.category),
                                repository.getPestsForCategory(species.category),
                                repository.getGraftMethodsForCategory(species.category)
                            ) { diseases, pests, grafts ->
                                Triple(diseases, pests, grafts)
                            }.collect { (diseases, pests, grafts) ->
                                _uiState.value = TreeDetailUiState(
                                    tree = tree,
                                    species = species,
                                    diseases = diseases,
                                    pests = pests,
                                    graftMethods = grafts,
                                    isLoading = false
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    fun updateNotes(notes: String) {
        viewModelScope.launch {
            repository.updateTreeNotes(treeId, notes)
        }
    }

    fun updateHealthStatus(status: HealthStatus, hasDisease: Boolean, hasPest: Boolean) {
        val current = _uiState.value.tree ?: return
        viewModelScope.launch {
            repository.updateTree(
                current.copy(healthStatus = status, hasDisease = hasDisease, hasPest = hasPest)
            )
        }
    }
}

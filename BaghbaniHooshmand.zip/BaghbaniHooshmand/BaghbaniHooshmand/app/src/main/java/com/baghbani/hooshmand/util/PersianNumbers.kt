package com.baghbani.hooshmand.util

/**
 * تبدیل اعداد انگلیسی به فارسی برای نمایش در UI (طبق تنظیمات کاربر).
 */
object PersianNumbers {

    private val enToFa = mapOf(
        '0' to '۰', '1' to '۱', '2' to '۲', '3' to '۳', '4' to '۴',
        '5' to '۵', '6' to '۶', '7' to '۷', '8' to '۸', '9' to '۹'
    )

    fun toPersian(input: String): String =
        input.map { enToFa[it] ?: it }.joinToString("")

    fun toPersian(number: Int): String = toPersian(number.toString())

    fun toPersian(number: Long): String = toPersian(number.toString())
}

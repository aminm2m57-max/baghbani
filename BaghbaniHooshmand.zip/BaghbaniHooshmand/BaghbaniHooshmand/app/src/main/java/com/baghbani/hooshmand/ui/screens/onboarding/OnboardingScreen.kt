package com.baghbani.hooshmand.ui.screens.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Park
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.datastore.SettingsDataStore
import com.baghbani.hooshmand.data.repository.GardenRepository

@Composable
fun OnboardingScreen(
    repository: GardenRepository,
    settingsDataStore: SettingsDataStore,
    onFinished: () -> Unit
) {
    val viewModel: OnboardingViewModel = viewModel(
        factory = viewModelFactory {
            initializer { OnboardingViewModel(repository, settingsDataStore) }
        }
    )
    var isLoading by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.Park,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(96.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "به باغبانی هوشمند خوش آمدید",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "این اپلیکیشن کاملاً آفلاین است و تمام اطلاعات باغبانی — از آبیاری و کوددهی تا بیماری‌ها، آفات و روش‌های پیوند — را به زبان فارسی در اختیار شما قرار می‌دهد.\n\n" +
                    "داده‌های مرجع فقط یک‌بار در همین مرحله بارگذاری می‌شوند و بعداً نیازی به ورود مجدد نیست.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = {
                    isLoading = true
                    viewModel.completeOnboarding { onFinished() }
                },
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("شروع کنید", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

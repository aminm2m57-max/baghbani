package com.baghbani.hooshmand.ui.screens.addtree

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.baghbani.hooshmand.data.repository.GardenRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTreeScreen(
    repository: GardenRepository,
    onBack: () -> Unit,
    onTreeAdded: (Long) -> Unit
) {
    val viewModel: AddTreeViewModel = viewModel(
        factory = viewModelFactory { initializer { AddTreeViewModel(repository) } }
    )
    val allSpecies by viewModel.allSpecies.collectAsState()

    var expanded by remember { mutableStateOf(false) }
    var selectedSpeciesId by remember { mutableStateOf<Long?>(null) }
    var nickname by remember { mutableStateOf("") }
    var ageYears by remember { mutableStateOf("") }
    var plantedYear by remember { mutableStateOf("") }

    val selectedSpecies = allSpecies.find { it.id == selectedSpeciesId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("افزودن درخت جدید") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("گونه درخت را انتخاب کنید", style = MaterialTheme.typography.titleMedium)

            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = selectedSpecies?.nameFa ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("گونه درخت") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    allSpecies.forEach { species ->
                        DropdownMenuItem(
                            text = { Text("${species.nameFa} (${species.scientificName})") },
                            onClick = {
                                selectedSpeciesId = species.id
                                expanded = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it },
                label = { Text("نام دلخواه (اختیاری)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = ageYears,
                onValueChange = { ageYears = it.filter { c -> c.isDigit() } },
                label = { Text("عمر تقریبی (سال)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = plantedYear,
                onValueChange = { plantedYear = it.filter { c -> c.isDigit() } },
                label = { Text("سال کاشت (شمسی - اختیاری)") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val speciesId = selectedSpeciesId ?: return@Button
                    viewModel.addTree(
                        speciesId = speciesId,
                        nickname = nickname.ifBlank { null },
                        plantedYear = plantedYear.toIntOrNull(),
                        ageYears = ageYears.toIntOrNull() ?: 0,
                        imageUri = null,
                        onDone = { id -> onTreeAdded(id) }
                    )
                },
                enabled = selectedSpeciesId != null,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("ذخیره درخت")
            }
        }
    }
}

package com.baghbani.hooshmand.data.seed

import com.baghbani.hooshmand.data.local.entity.GraftMethodEntity
import com.baghbani.hooshmand.data.local.entity.TreeCategory

/**
 * فقط انواع پیوند واقعی و متداول برای هر دسته درخت.
 * دسته‌های انجیر/توت (SPECIAL) و خرما (PALM) به‌طور معمول پیوند تجاری رایج ندارند
 * و در UI پیام «برای این درخت روش پیوند رایجی ثبت نشده» نمایش داده می‌شود.
 */
object GraftMethodSeed {

    fun list(): List<GraftMethodEntity> = listOf(
        // ---------- میوه دانه‌دار: سیب، گلابی، به ----------
        GraftMethodEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "پیوند شاخه‌ای (لوله‌ای/انگلیسی)",
            bestSeason = "اواخر زمستان تا اوایل بهار (قبل از باز شدن جوانه)",
            idealTemperature = "۱۰ تا ۱۸ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه را در ارتفاع مناسب با چاقوی پیوندزنی تیز قطع کنید",
                "برش مورب یکسان روی پایه و پیوندک ایجاد کنید",
                "پیوندک را دقیقاً روی پایه قرار داده و کامبیوم‌ها را منطبق کنید",
                "محل اتصال را با نوار پیوند محکم ببندید",
                "روی محل بسته‌شده را با پارافین یا خمیر پیوند بپوشانید"
            ),
            requiredTools = listOf("چاقوی پیوندزنی تیز", "نوار پیوند", "خمیر یا پارافین پیوند", "پیوندک سالم یک‌ساله"),
            aftercareInfo = "محل پیوند را از باد و آفتاب مستقیم شدید محافظت کنید و نوار را بعد از جوش‌خوردن کامل باز کنید.",
            shadeNeeded = false, firstDaysCareCount = 20, approxSuccessRate = 80
        ),
        GraftMethodEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "پیوند تاجی (Crown Graft)",
            bestSeason = "اوایل بهار هنگام روان شدن شیره گیاهی",
            idealTemperature = "۱۵ تا ۲۰ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه ضخیم را صاف قطع کنید",
                "پوست پایه را با چاقو کمی شکاف دهید",
                "پیوندک تراشیده‌شده را زیر پوست پایه جای دهید",
                "محل را با نوار پیوند ببندید و با خمیر پیوند بپوشانید"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "خمیر پیوند"),
            aftercareInfo = "در دو هفته اول از تنش آبی درخت جلوگیری کنید و جوانه‌های اضافی پایه را حذف کنید.",
            shadeNeeded = false, firstDaysCareCount = 15, approxSuccessRate = 75
        ),
        GraftMethodEntity(
            category = TreeCategory.POME_FRUIT, nameFa = "پیوند جوانه‌ای شکمی (T)",
            bestSeason = "اواخر تابستان (شهریور)",
            idealTemperature = "۲۰ تا ۲۸ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "روی پوست پایه یک برش T شکل ایجاد کنید",
                "جوانه سالم را همراه با کمی چوب از شاخه پیوندک جدا کنید",
                "جوانه را زیر پوست باز شده در محل T جای دهید",
                "محل را با نوار پیوند ببندید و فقط جوانه را باز بگذارید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری", "نوار پیوند پلاستیکی"),
            aftercareInfo = "بعد از ۳ هفته نوار را شل کرده و در صورت جوش‌خوردن، شاخه بالای جوانه را در بهار سال بعد قطع کنید.",
            shadeNeeded = false, firstDaysCareCount = 21, approxSuccessRate = 85
        ),

        // ---------- میوه هسته‌دار ----------
        GraftMethodEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "پیوند جوانه‌ای شکمی (T)",
            bestSeason = "تیر تا شهریور",
            idealTemperature = "۲۲ تا ۳۰ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "برش T روی پوست پایه در ارتفاع ۱۵ تا ۲۰ سانتی‌متری از خاک ایجاد کنید",
                "جوانه سالم را با پوست نازک از شاخه پیوندک جدا کنید",
                "جوانه را داخل شکاف T جای داده و محکم کنید",
                "با نوار پیوند ببندید و جوانه را آزاد بگذارید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری تیز", "نوار پیوند"),
            aftercareInfo = "آبیاری منظم اما بدون رطوبت مستقیم روی محل پیوند تا جوش‌خوردن کامل ادامه یابد.",
            shadeNeeded = false, firstDaysCareCount = 20, approxSuccessRate = 80
        ),
        GraftMethodEntity(
            category = TreeCategory.STONE_FRUIT, nameFa = "پیوند شاخه‌ای (Whip and Tongue)",
            bestSeason = "اواخر زمستان قبل از باز شدن جوانه",
            idealTemperature = "۱۰ تا ۱۶ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "برش مورب بلند روی پایه و پیوندک ایجاد کنید",
                "روی هر برش یک زبانه کوچک ایجاد کنید تا دو قطعه قفل شوند",
                "پیوندک و پایه را محکم به هم متصل کنید",
                "محل را با نوار پیوند و خمیر پیوند بپوشانید"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "خمیر پیوند"),
            aftercareInfo = "درخت را از باد شدید محافظت کنید؛ در صورت نیاز از قیم نگهدارنده استفاده کنید.",
            shadeNeeded = true, firstDaysCareCount = 15, approxSuccessRate = 70
        ),

        // ---------- انگور ----------
        GraftMethodEntity(
            category = TreeCategory.VINE, nameFa = "پیوند انگلیسی (Whip Graft)",
            bestSeason = "اواخر زمستان تا اوایل بهار",
            idealTemperature = "۱۲ تا ۱۸ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه و پیوندک هم‌قطر انتخاب و برش مورب یکسان بزنید",
                "دو قطعه را با انطباق کامل کامبیوم به‌هم متصل کنید",
                "محل اتصال را با نوار پیوند مخصوص انگور ببندید",
                "روی محل را با پارافین بپوشانید تا رطوبت حفظ شود"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "پارافین"),
            aftercareInfo = "تا جوش‌خوردن کامل از خشکی خاک جلوگیری کنید و شاخه‌های هرز پایه را حذف کنید.",
            shadeNeeded = false, firstDaysCareCount = 25, approxSuccessRate = 65
        ),
        GraftMethodEntity(
            category = TreeCategory.VINE, nameFa = "پیوند شکافی (Cleft Graft)",
            bestSeason = "اواخر زمستان",
            idealTemperature = "۱۰ تا ۱۵ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه را صاف قطع کرده و در وسط شکاف دهید",
                "پیوندک را به شکل گوه‌ای تراشیده و داخل شکاف جای دهید",
                "محل را محکم ببندید و با خمیر پیوند بپوشانید"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "خمیر پیوند"),
            aftercareInfo = "در دو هفته اول رطوبت خاک را ثابت نگه دارید.",
            shadeNeeded = false, firstDaysCareCount = 20, approxSuccessRate = 60
        ),

        // ---------- انار ----------
        GraftMethodEntity(
            category = TreeCategory.POMEGRANATE, nameFa = "پیوند شکمی انار",
            bestSeason = "اواخر بهار تا اوایل تابستان",
            idealTemperature = "۲۰ تا ۲۸ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "برش شکمی روی پوست پایه در نزدیکی طوقه ایجاد کنید",
                "جوانه انتخابی را با پوست نازک از پیوندک جدا کنید",
                "جوانه را داخل شکاف جای داده و محکم کنید",
                "با نوار پیوند نازک ببندید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری", "نوار پیوند"),
            aftercareInfo = "به دلیل بوته‌ای بودن انار، پاجوش‌های اضافی اطراف پایه را مرتب حذف کنید.",
            shadeNeeded = true, firstDaysCareCount = 15, approxSuccessRate = 70
        ),
        GraftMethodEntity(
            category = TreeCategory.POMEGRANATE, nameFa = "قلمه‌زنی (روش رایج تکثیر انار)",
            bestSeason = "زمستان (خواب گیاه)",
            idealTemperature = "۵ تا ۱۵ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "قلمه ۲۰ تا ۳۰ سانتی‌متری از شاخه یک‌ساله سالم تهیه کنید",
                "انتهای قلمه را در هورمون ریشه‌زایی فرو ببرید",
                "قلمه را در خاک سبک و مرطوب بکارید",
                "تا ریشه‌دار شدن کامل، خاک را مرطوب نگه دارید"
            ),
            requiredTools = listOf("قیچی باغبانی تیز", "هورمون ریشه‌زایی", "خاک سبک گلدانی"),
            aftercareInfo = "قلمه‌ها را از آفتاب مستقیم شدید و یخبندان محافظت کنید تا ریشه‌دهی کامل شود.",
            shadeNeeded = true, firstDaysCareCount = 30, approxSuccessRate = 65
        ),

        // ---------- آجیلی: پسته، گردو ----------
        GraftMethodEntity(
            category = TreeCategory.NUT, nameFa = "پیوند شکمی پسته (روی پایه بنه)",
            bestSeason = "اواخر تابستان",
            idealTemperature = "۲۵ تا ۳۲ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه بنه یا پسته وحشی حداقل دوساله را آماده کنید",
                "برش شکمی روی پوست پایه ایجاد کنید",
                "جوانه سالم پیوندک را داخل شکاف جای دهید",
                "با نوار پیوند مخصوص پسته محکم ببندید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری", "نوار پیوند"),
            aftercareInfo = "در ماه‌های اول از تنش گرمایی شدید و آفتاب‌سوختگی محل پیوند جلوگیری کنید.",
            shadeNeeded = true, firstDaysCareCount = 25, approxSuccessRate = 75
        ),
        GraftMethodEntity(
            category = TreeCategory.NUT, nameFa = "پیوند شاخه‌ای بهاره (گردو و پسته)",
            bestSeason = "اوایل بهار هنگام روان شدن شیره",
            idealTemperature = "۱۸ تا ۲۴ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه و پیوندک هم‌قطر انتخاب کنید",
                "برش مورب مشابه روی هر دو ایجاد کنید",
                "دو قطعه را منطبق کرده و با نوار پیوند ببندید",
                "روی محل را با خمیر پیوند بپوشانید تا از خشک‌شدن جلوگیری شود"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "خمیر پیوند"),
            aftercareInfo = "گردو به دلیل ترشح شیره زیاد نیاز به دقت بالا دارد؛ محل پیوند را در روزهای اول بازرسی کنید.",
            shadeNeeded = false, firstDaysCareCount = 20, approxSuccessRate = 55
        ),

        // ---------- مرکبات ----------
        GraftMethodEntity(
            category = TreeCategory.CITRUS, nameFa = "پیوند جوانه‌ای شکمی مرکبات (روی پایه نارنج)",
            bestSeason = "بهار و اواخر تابستان",
            idealTemperature = "۲۲ تا ۳۰ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه نارنج یک تا دوساله را آماده کنید",
                "برش T روی پوست پایه در ارتفاع مناسب ایجاد کنید",
                "جوانه سالم پیوندک مرکبات را جدا و در شکاف جای دهید",
                "با نوار پیوند مخصوص ببندید و جوانه را باز بگذارید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری", "نوار پیوند مخصوص مرکبات"),
            aftercareInfo = "مرکبات به سرما حساس‌اند؛ در ماه‌های اول از یخبندان و آفتاب شدید محافظت کنید.",
            shadeNeeded = true, firstDaysCareCount = 20, approxSuccessRate = 80
        ),

        // ---------- زیتون ----------
        GraftMethodEntity(
            category = TreeCategory.OLIVE, nameFa = "پیوند شکمی زیتون",
            bestSeason = "اواخر بهار تا اواسط تابستان",
            idealTemperature = "۲۲ تا ۲۸ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه زیتون وحشی یا رقم پابلند را آماده کنید",
                "برش شکمی روی پوست پایه ایجاد کنید",
                "جوانه رقم مرغوب را داخل شکاف جای دهید",
                "با نوار پیوند ببندید"
            ),
            requiredTools = listOf("چاقوی جوانه‌گیری", "نوار پیوند"),
            aftercareInfo = "زیتون رشد کندی دارد؛ صبر لازم است تا جوش‌خوردن کامل مشخص شود (حدود ۴ تا ۶ هفته).",
            shadeNeeded = true, firstDaysCareCount = 30, approxSuccessRate = 70
        ),
        GraftMethodEntity(
            category = TreeCategory.OLIVE, nameFa = "پیوند شاخه‌ای زیتون",
            bestSeason = "اوایل بهار",
            idealTemperature = "۱۵ تا ۲۰ درجه سانتی‌گراد",
            procedureSteps = listOf(
                "پایه و پیوندک هم‌قطر را با برش مورب آماده کنید",
                "دو قطعه را منطبق کرده و محکم ببندید",
                "روی محل را با خمیر پیوند بپوشانید"
            ),
            requiredTools = listOf("چاقوی پیوندزنی", "نوار پیوند", "خمیر پیوند"),
            aftercareInfo = "تا استقرار کامل از تنش خشکی جلوگیری کنید.",
            shadeNeeded = false, firstDaysCareCount = 25, approxSuccessRate = 60
        )

        // توجه: برای انجیر و توت (دسته SPECIAL) و همچنین خرما (PALM)
        // به‌عمد هیچ GraftMethodEntity ثبت نشده، چون این درختان پیوند تجاری رایجی ندارند؛
        // در UI پیام «روش پیوند رایجی برای این درخت ثبت نشده» نمایش داده می‌شود.
    )
}

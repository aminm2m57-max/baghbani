package com.baghbani.hooshmand.data.local.converter

import androidx.room.TypeConverter
import com.baghbani.hooshmand.data.local.entity.ActivityType
import com.baghbani.hooshmand.data.local.entity.HealthStatus
import com.baghbani.hooshmand.data.local.entity.TreeCategory

class Converters {

    // ---------- List<String> (مراحل، ابزار و ...) ----------
    @TypeConverter
    fun fromStringList(list: List<String>): String = list.joinToString(SEPARATOR)

    @TypeConverter
    fun toStringList(data: String): List<String> =
        if (data.isEmpty()) emptyList() else data.split(SEPARATOR)

    // ---------- TreeCategory ----------
    @TypeConverter
    fun fromTreeCategory(value: TreeCategory): String = value.name

    @TypeConverter
    fun toTreeCategory(value: String): TreeCategory = TreeCategory.valueOf(value)

    // ---------- HealthStatus ----------
    @TypeConverter
    fun fromHealthStatus(value: HealthStatus): String = value.name

    @TypeConverter
    fun toHealthStatus(value: String): HealthStatus = HealthStatus.valueOf(value)

    // ---------- ActivityType ----------
    @TypeConverter
    fun fromActivityType(value: ActivityType): String = value.name

    @TypeConverter
    fun toActivityType(value: String): ActivityType = ActivityType.valueOf(value)

    companion object {
        private const val SEPARATOR = "|||"
    }
}

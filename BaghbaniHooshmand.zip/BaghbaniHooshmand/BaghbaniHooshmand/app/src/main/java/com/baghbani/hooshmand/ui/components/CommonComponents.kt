package com.baghbani.hooshmand.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.baghbani.hooshmand.data.local.entity.HealthStatus
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity
import com.baghbani.hooshmand.ui.screens.home.TreeWithSpecies
import com.baghbani.hooshmand.ui.theme.StatusDanger
import com.baghbani.hooshmand.ui.theme.StatusHealthy
import com.baghbani.hooshmand.ui.theme.StatusWarning
import com.baghbani.hooshmand.util.PersianNumbers

/** کارت کوچک نمایش یک درخت در لیست/صفحه اصلی */
@Composable
fun TreeSummaryCard(item: TreeWithSpecies, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
            ) {
                AsyncImage(
                    model = item.tree.imageUri,
                    contentDescription = item.species.nameFa,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(item.species.nameFa, style = MaterialTheme.typography.titleMedium)
                Text(
                    item.species.scientificName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "عمر: ${PersianNumbers.toPersian(item.tree.ageYears)} سال",
                    style = MaterialTheme.typography.labelMedium
                )
            }
            HealthStatusChip(status = item.tree.healthStatus)
        }
    }
}

@Composable
fun HealthStatusChip(status: HealthStatus) {
    val color = when (status) {
        HealthStatus.HEALTHY -> StatusHealthy
        HealthStatus.MINOR_ISSUE -> StatusWarning
        HealthStatus.DISEASED, HealthStatus.PEST_AFFECTED -> StatusDanger
        HealthStatus.CRITICAL -> StatusDanger
    }
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(50),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Circle, contentDescription = null, tint = color, modifier = Modifier.size(8.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(status.displayNameFa, style = MaterialTheme.typography.labelMedium, color = color)
        }
    }
}

/** بخش قابل‌تاشو با آیکون، برای صفحه جزئیات درخت (آبیاری، کوددهی، بیماری و...) */
@Composable
fun ExpandableSection(
    title: String,
    icon: ImageVector,
    initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(initiallyExpanded) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Icon(
                    imageVector = if (expanded) androidx.compose.material.icons.Icons.Filled.KeyboardArrowUp
                    else androidx.compose.material.icons.Icons.Filled.KeyboardArrowDown,
                    contentDescription = null
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                content()
            }
        }
    }
}

/** یک ردیف برچسب + مقدار، برای اطلاعات پایه */
@Composable
fun IconLabelRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** نمایش لیست مراحل گام‌به‌گام (راه‌حل بیماری، روش پیوند و ...) */
@Composable
fun StepsList(steps: List<String>) {
    Column {
        steps.forEachIndexed { index, step ->
            Row(modifier = Modifier.padding(vertical = 3.dp)) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        PersianNumbers.toPersian(index + 1),
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(step, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            }
        }
    }
}

/** کارت آمار کوچک برای صفحه اصلی (تعداد درخت، درصد سلامت، ...) */
@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = color)
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, style = MaterialTheme.typography.labelMedium)
        }
    }
}

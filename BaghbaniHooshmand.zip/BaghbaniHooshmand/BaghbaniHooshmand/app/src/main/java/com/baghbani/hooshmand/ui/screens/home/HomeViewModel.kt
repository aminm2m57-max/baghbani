package com.baghbani.hooshmand.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.local.entity.TreeEntity
import com.baghbani.hooshmand.data.local.entity.TreeSpeciesEntity
import com.baghbani.hooshmand.data.repository.GardenRepository
import kotlinx.coroutines.flow.*

data class TreeWithSpecies(val tree: TreeEntity, val species: TreeSpeciesEntity)

data class HomeUiState(
    val treesWithSpecies: List<TreeWithSpecies> = emptyList(),
    val totalCount: Int = 0,
    val healthyPercent: Int = 0,
    val diseaseCount: Int = 0,
    val pestCount: Int = 0,
    val isLoading: Boolean = true
)

class HomeViewModel(private val repository: GardenRepository) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        repository.getAllTrees(),
        repository.getAllSpecies(),
        repository.getTreeCount(),
        repository.getHealthyCount(),
        repository.getDiseasedCount(),
        repository.getPestAffectedCount()
    ) { flows ->
        @Suppress("UNCHECKED_CAST")
        val trees = flows[0] as List<TreeEntity>
        @Suppress("UNCHECKED_CAST")
        val species = flows[1] as List<TreeSpeciesEntity>
        val total = flows[2] as Int
        val healthy = flows[3] as Int
        val diseased = flows[4] as Int
        val pestAffected = flows[5] as Int

        val speciesMap = species.associateBy { it.id }
        val combined = trees.mapNotNull { t -> speciesMap[t.speciesId]?.let { TreeWithSpecies(t, it) } }

        HomeUiState(
            treesWithSpecies = combined,
            totalCount = total,
            healthyPercent = if (total > 0) (healthy * 100) / total else 0,
            diseaseCount = diseased,
            pestCount = pestAffected,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}

package com.baghbani.hooshmand.data.local.dao

import androidx.room.*
import com.baghbani.hooshmand.data.local.entity.ActivityEntity
import com.baghbani.hooshmand.data.local.entity.GrowthRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activities ORDER BY date DESC")
    fun getAllActivities(): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities WHERE treeId = :treeId ORDER BY date DESC")
    fun getActivitiesForTree(treeId: Long): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities WHERE isFutureReminder = 1 AND isCompleted = 0 ORDER BY date ASC")
    fun getUpcomingActivities(): Flow<List<ActivityEntity>>

    @Insert
    suspend fun insert(activity: ActivityEntity): Long

    @Update
    suspend fun update(activity: ActivityEntity)

    @Delete
    suspend fun delete(activity: ActivityEntity)
}

@Dao
interface GrowthRecordDao {
    @Query("SELECT * FROM growth_records WHERE treeId = :treeId ORDER BY year ASC")
    fun getGrowthRecordsForTree(treeId: Long): Flow<List<GrowthRecordEntity>>

    @Insert
    suspend fun insert(record: GrowthRecordEntity): Long

    @Update
    suspend fun update(record: GrowthRecordEntity)
}

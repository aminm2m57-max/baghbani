package com.baghbani.hooshmand.ui.screens.garden

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baghbani.hooshmand.data.local.entity.ActivityEntity
import com.baghbani.hooshmand.data.local.entity.ActivityType
import com.baghbani.hooshmand.data.repository.GardenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GardenManagementViewModel(private val repository: GardenRepository) : ViewModel() {

    val upcomingActivities: StateFlow<List<ActivityEntity>> =
        repository.getUpcomingActivities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allActivities: StateFlow<List<ActivityEntity>> =
        repository.getAllActivities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val priorityDiseases = repository.getAllDiseasesSortedByPriority()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val priorityPests = repository.getAllPestsSortedByPriority()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addActivity(
        treeId: Long,
        type: ActivityType,
        date: Long,
        description: String,
        imageBeforeUri: String?,
        imageAfterUri: String?,
        isFutureReminder: Boolean
    ) {
        viewModelScope.launch {
            repository.addActivity(
                ActivityEntity(
                    treeId = treeId,
                    type = type,
                    date = date,
                    description = description,
                    imageBeforeUri = imageBeforeUri,
                    imageAfterUri = imageAfterUri,
                    isFutureReminder = isFutureReminder,
                    isCompleted = !isFutureReminder
                )
            )
        }
    }

    fun markCompleted(activity: ActivityEntity) {
        viewModelScope.launch {
            repository.updateActivity(activity.copy(isCompleted = true))
        }
    }
}

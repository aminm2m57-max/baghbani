# باغبانی هوشمند 🌳

اپلیکیشن آفلاین اندروید برای مدیریت باغ شخصی — نوشته‌شده با Jetpack Compose، Room Database و DataStore.

## نحوه باز کردن پروژه

1. Android Studio (نسخه Koala یا جدیدتر) را باز کنید.
2. گزینه **Open** را انتخاب کرده و پوشه `BaghbaniHooshmand` را انتخاب کنید.
3. صبر کنید تا Gradle Sync به‌طور خودکار انجام شود (Android Studio فایل‌های Gradle Wrapper را در صورت نبود، خودش می‌سازد).
4. پروژه را روی شبیه‌ساز یا گوشی اجرا کنید (Run ▶).

> **نکته:** چون این پروژه خارج از Android Studio (بدون دسترسی به اینترنت) ساخته شده، فایل باینری `gradle-wrapper.jar` همراه آن نیست. Android Studio هنگام باز کردن پروژه به‌صورت خودکار آن را می‌سازد. اگر با خطای wrapper مواجه شدید، از منوی Android Studio گزینه **File > Sync Project with Gradle Files** را بزنید یا دستور `gradle wrapper` را در ترمینال اجرا کنید.

## ساختار پروژه

```
app/src/main/java/com/baghbani/hooshmand/
├── data/
│   ├── local/          → Entity ها، DAO ها، AppDatabase (Room)
│   ├── datastore/       → تنظیمات کاربر (DataStore)
│   ├── repository/      → GardenRepository (لایه واسط)
│   └── seed/             → داده مرجع ۲۰ گونه درخت + بیماری/آفت/پیوند
├── ui/
│   ├── screens/          → هر صفحه در پوشه خودش (home، treelist، treedetail، addtree، garden، general، settings، onboarding)
│   ├── components/       → کامپوننت‌های Compose قابل‌استفاده مجدد
│   ├── theme/             → رنگ، تایپوگرافی، تم Material3 (سبز طبیعی + RTL)
│   └── navigation/        → NavHost و مسیرها
└── util/                  → تبدیل اعداد فارسی و تاریخ شمسی
```

## نکات مهم برای تکمیل پروژه

- **فونت فارسی:** در حال حاضر از فونت پیش‌فرض سیستم (Sans Serif) استفاده می‌شود. برای ظاهر حرفه‌ای‌تر، فونت [Vazirmatn](https://github.com/rastikerdar/vazirmatn) را در `res/font/` قرار داده و طبق راهنمای داخل `ui/theme/Type.kt` فعال کنید.
- **تصاویر درخت‌ها/بیماری‌ها/آفات:** فیلدهای `imageRes` در داده‌های Seed فقط نام مرجع هستند (مثلاً `tree_apple`). برای نمایش تصویر واقعی، عکس‌های مربوطه را در `res/drawable/` اضافه کرده و منطق نگاشت نام به `painterResource` را در کامپوننت‌های مربوطه اضافه کنید. تصویر شخصی هر درخت (`imageUri`) از طریق Coil و انتخاب‌گر تصویر گوشی قابل تنظیم است (منطق انتخاب عکس در `AddTreeScreen`/`TreeDetailScreen` باید تکمیل شود).
- **آیکون اپ:** یک آیکون Vector ساده (برگ سبز) به‌عنوان جای‌گذار ساخته شده؛ در صورت تمایل با Image Asset Studio در Android Studio جایگزین کنید.

## معماری

MVVM ساده بدون Hilt (تزریق وابستگی دستی از طریق `BaghbaniApp` و `viewModelFactory { initializer { ... } }` در هر Composable).

## دیتابیس

تمام داده‌ها آفلاین در Room ذخیره می‌شوند. کاتالوگ مرجع (گونه‌ها، بیماری‌ها، آفات، روش‌های پیوند) فقط یک‌بار در صفحه معرفی (Onboarding) Seed می‌شود و کاربر می‌تواند بعداً درخت‌های شخصی خودش را اضافه/ویرایش کند.
